import type { Vector3 } from 'three'

type Emitter = (pos: Vector3, count: number, color: string, speed: number, life?: number) => void
type Shock = (pos: Vector3, color: string) => void

export const fxBus: { emit: Emitter | null; shock: Shock | null } = {
  emit: null,
  shock: null,
}

export const HALF_W = 34
export const HALF_L = 52
export const WALL_H = 22
export const GOAL_HALF_W = 9
export const GOAL_H = 7.5
export const GOAL_DEPTH = 6
export const POST_R = 0.35

export const BALL_R = 1.15
export const GRAVITY = 30

export const ROBOT_R = 1.05
export const ROBOT_H = 3.2

export const SIM_DT = 1 / 120

export const TEAMS = [
  { name: 'NEON', short: 'NEO', main: '#1d8bff', glow: '#4cc9ff', dark: '#0a2c5c' },
  { name: 'INFERNO', short: 'INF', main: '#ff5a1f', glow: '#ffa23a', dark: '#5c1d08' },
] as const

export type Difficulty = 'rookie' | 'pro' | 'legend'

export const DIFFICULTY: Record<
  Difficulty,
  { speed: number; think: number; tackle: number; aimError: number; steal: number; catchSpeed: number }
> = {
  rookie: { speed: 0.84, think: 0.42, tackle: 0.25, aimError: 0.55, steal: 0.45, catchSpeed: 20 },
  pro: { speed: 0.95, think: 0.28, tackle: 0.45, aimError: 0.3, steal: 0.8, catchSpeed: 25 },
  legend: { speed: 1.04, think: 0.16, tackle: 0.7, aimError: 0.14, steal: 1.25, catchSpeed: 30 },
}

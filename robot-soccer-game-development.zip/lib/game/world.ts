import { Vector3 } from 'three'
import { BALL_R, HALF_L, type Difficulty } from './constants'

export type Role = 'keeper' | 'defender' | 'striker'
export type RobotState = 'normal' | 'slide' | 'stun' | 'skill'
export type Phase = 'kickoff' | 'playing' | 'goal' | 'ended'

export interface Intent {
  mx: number
  mz: number
  sprint: boolean
  jump: boolean
}

export interface QueuedAction {
  type: 'shot' | 'pass' | 'lob'
  charge: number
  aimX: number
  aimZ: number
  t: number
}

export interface Robot {
  id: number
  team: 0 | 1
  role: Role
  name: string
  number: number
  pos: Vector3
  vel: Vector3
  facing: number
  onGround: boolean
  airTime: number
  boost: number
  boosting: boolean
  thrust: number
  state: RobotState
  stateTime: number
  kickCooldown: number
  grabCooldown: number
  tackleCooldown: number
  skillCooldown: number
  kickAnim: number
  animPhase: number
  receiveTimer: number
  holdTime: number
  aiThink: number
  aimX: number
  queued: QueuedAction | null
  intent: Intent
}

export interface Pad {
  pos: Vector3
  big: boolean
  active: boolean
  timer: number
}

export type FxType = 'goal' | 'kick' | 'bounce' | 'post' | 'demo' | 'pad' | 'tackle' | 'whistle' | 'catch'

export interface FxEvent {
  type: FxType
  pos: Vector3
  team?: number
  power?: number
}

export interface World {
  ball: { pos: Vector3; vel: Vector3; lastTouchTeam: number; lastTouchId: number }
  robots: Robot[]
  pads: Pad[]
  possessor: number
  controlled: number
  phase: Phase
  phaseTime: number
  score: [number, number]
  clock: number
  overtime: boolean
  kickoffTeam: 0 | 1
  lastScorer: { team: number; name: string } | null
  goalPos: Vector3
  shake: number
  demo: boolean
  difficulty: Difficulty
  matchSeconds: number
  events: FxEvent[]
  time: number
}

const ROSTER: { name: string; role: Role; number: number }[][] = [
  [
    { name: 'AEGIS', role: 'keeper', number: 1 },
    { name: 'TITAN', role: 'defender', number: 4 },
    { name: 'VOLT', role: 'striker', number: 9 },
  ],
  [
    { name: 'BASTION', role: 'keeper', number: 1 },
    { name: 'FORGE', role: 'defender', number: 5 },
    { name: 'BLAZE', role: 'striker', number: 10 },
  ],
]

function makeRobot(id: number, team: 0 | 1, info: (typeof ROSTER)[0][0]): Robot {
  return {
    id,
    team,
    role: info.role,
    name: info.name,
    number: info.number,
    pos: new Vector3(),
    vel: new Vector3(),
    facing: team === 0 ? 0 : Math.PI,
    onGround: true,
    airTime: 0,
    boost: 40,
    boosting: false,
    thrust: 0,
    state: 'normal',
    stateTime: 0,
    kickCooldown: 0,
    grabCooldown: 0,
    tackleCooldown: 0,
    skillCooldown: 0,
    kickAnim: 0,
    animPhase: Math.random() * 6,
    receiveTimer: 0,
    holdTime: 0,
    aiThink: 0,
    aimX: 0,
    queued: null,
    intent: { mx: 0, mz: 0, sprint: false, jump: false },
  }
}

function makePads(): Pad[] {
  const list: [number, number, boolean][] = [
    [-28, -32, true],
    [28, -32, true],
    [-28, 32, true],
    [28, 32, true],
    [0, -26, false],
    [0, 26, false],
    [-20, 0, false],
    [20, 0, false],
    [-12, -42, false],
    [12, -42, false],
    [-12, 42, false],
    [12, 42, false],
  ]
  return list.map(([x, z, big]) => ({ pos: new Vector3(x, 0, z), big, active: true, timer: 0 }))
}

function createWorld(): World {
  const robots: Robot[] = []
  let id = 0
  for (const team of [0, 1] as const) {
    for (const info of ROSTER[team]) robots.push(makeRobot(id++, team, info))
  }
  return {
    ball: { pos: new Vector3(0, BALL_R, 0), vel: new Vector3(), lastTouchTeam: -1, lastTouchId: -1 },
    robots,
    pads: makePads(),
    possessor: -1,
    controlled: 2,
    phase: 'kickoff',
    phaseTime: 0,
    score: [0, 0],
    clock: 180,
    overtime: false,
    kickoffTeam: 0,
    lastScorer: null,
    goalPos: new Vector3(),
    shake: 0,
    demo: true,
    difficulty: 'pro',
    matchSeconds: 180,
    events: [],
    time: 0,
  }
}

export const world: World = createWorld()

export function forwardOf(r: Robot) {
  return { x: Math.sin(r.facing), z: Math.cos(r.facing) }
}

export function attackDir(team: number) {
  return team === 0 ? 1 : -1
}

export function resetKickoff(w: World) {
  w.ball.pos.set(0, BALL_R, 0)
  w.ball.vel.set(0, 0, 0)
  w.ball.lastTouchTeam = -1
  w.ball.lastTouchId = -1
  w.possessor = -1
  w.phase = 'kickoff'
  w.phaseTime = 0
  for (const r of w.robots) {
    const s = attackDir(r.team)
    const kicking = r.team === w.kickoffTeam
    if (r.role === 'keeper') r.pos.set(0, 0, -s * (HALF_L - 3))
    else if (r.role === 'defender') r.pos.set(r.team === 0 ? -12 : 12, 0, -s * 22)
    else r.pos.set(kicking ? 0 : r.team === 0 ? 6 : -6, 0, -s * (kicking ? 4.2 : 14))
    r.vel.set(0, 0, 0)
    r.facing = r.team === 0 ? 0 : Math.PI
    r.onGround = true
    r.state = 'normal'
    r.stateTime = 0
    r.kickCooldown = 0
    r.grabCooldown = 0
    r.queued = null
    r.receiveTimer = 0
    r.holdTime = 0
    r.boost = Math.max(r.boost, 34)
    r.thrust = 0
  }
  for (const p of w.pads) {
    p.active = true
    p.timer = 0
  }
  if (!w.demo) {
    const striker = w.robots.find((r) => r.team === 0 && r.role === 'striker')
    if (striker) w.controlled = striker.id
  }
}

export function startMatch(w: World, opts: { demo: boolean; difficulty: Difficulty; minutes: number }) {
  w.demo = opts.demo
  w.difficulty = opts.difficulty
  w.matchSeconds = opts.minutes * 60
  w.clock = w.matchSeconds
  w.score = [0, 0]
  w.overtime = false
  w.lastScorer = null
  w.kickoffTeam = Math.random() < 0.5 ? 0 : 1
  w.controlled = opts.demo ? -1 : 2
  w.events.length = 0
  for (const r of w.robots) r.boost = 34
  resetKickoff(w)
}

startMatch(world, { demo: true, difficulty: 'pro', minutes: 3 })

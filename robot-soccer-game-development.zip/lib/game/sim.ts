import { Vector3 } from 'three'
import {
  BALL_R,
  DIFFICULTY,
  GOAL_DEPTH,
  GOAL_H,
  GOAL_HALF_W,
  GRAVITY,
  HALF_L,
  HALF_W,
  POST_R,
  ROBOT_H,
  ROBOT_R,
  WALL_H,
} from './constants'
import { reachOf, shoot, pass } from './actions'
import { attackDir, forwardOf, type Robot, type World } from './world'

const tmpA = new Vector3()
const tmpB = new Vector3()
const tmpN = new Vector3()

function moveRobot(w: World, r: Robot, dt: number) {
  const it = r.intent
  const isAI = r.id !== w.controlled
  const diff = DIFFICULTY[w.difficulty]
  const speedMul = isAI ? diff.speed : 1

  r.kickCooldown = Math.max(0, r.kickCooldown - dt)
  r.grabCooldown = Math.max(0, r.grabCooldown - dt)
  r.tackleCooldown = Math.max(0, r.tackleCooldown - dt)
  r.skillCooldown = Math.max(0, r.skillCooldown - dt)
  r.receiveTimer = Math.max(0, r.receiveTimer - dt)
  r.kickAnim = Math.max(0, r.kickAnim - dt / 0.32)

  if (r.state !== 'normal') {
    r.stateTime -= dt
    if (r.stateTime <= 0) r.state = 'normal'
  }

  const hasBall = w.possessor === r.id
  let usingBoost = false
  const mlen = Math.hypot(it.mx, it.mz)

  if (r.state === 'normal') {
    const wantsSprint = it.sprint && r.boost > 0 && mlen > 0.2
    let max = (wantsSprint ? 19.5 : hasBall ? 12.2 : 13.5) * speedMul
    if (r.role === 'keeper' && !wantsSprint) max *= 1.05
    const tx = it.mx * max
    const tz = it.mz * max
    const accel = r.onGround ? (wantsSprint ? 9 : 7.5) : 2.2
    const k = Math.min(1, accel * dt)
    r.vel.x += (tx - r.vel.x) * k
    r.vel.z += (tz - r.vel.z) * k
    if (wantsSprint && r.onGround) {
      usingBoost = true
      r.boost = Math.max(0, r.boost - 20 * dt)
    }
    if (mlen > 0.12) {
      const target = Math.atan2(it.mx, it.mz)
      let delta = target - r.facing
      delta = Math.atan2(Math.sin(delta), Math.cos(delta))
      const turn = (hasBall ? 9 : 13) * dt
      r.facing += Math.max(-turn, Math.min(turn, delta))
    }
  } else if (r.state === 'slide') {
    r.vel.x *= 1 - 2.6 * dt
    r.vel.z *= 1 - 2.6 * dt
  } else if (r.state === 'skill') {
    const f = forwardOf(r)
    r.vel.x = f.x * 17
    r.vel.z = f.z * 17
  } else if (r.state === 'stun') {
    if (r.onGround) {
      r.vel.x *= 1 - 4 * dt
      r.vel.z *= 1 - 4 * dt
    }
  }

  r.vel.y -= GRAVITY * dt
  if (!r.onGround) {
    r.airTime += dt
    if (it.jump && r.boost > 0 && r.airTime > 0.18 && r.state !== 'stun') {
      r.vel.y += 46 * dt
      r.boost = Math.max(0, r.boost - 28 * dt)
      usingBoost = true
      if (mlen > 0.1) {
        r.vel.x += it.mx * 14 * dt
        r.vel.z += it.mz * 14 * dt
      }
    }
    r.vel.y = Math.min(r.vel.y, 16)
  }
  r.boosting = usingBoost
  r.thrust += ((usingBoost ? 1 : 0) - r.thrust) * Math.min(1, 12 * dt)

  if (r.onGround && !usingBoost) r.boost = Math.min(100, r.boost + 4 * dt)

  r.pos.addScaledVector(r.vel, dt)

  if (r.pos.y <= 0) {
    r.pos.y = 0
    if (!r.onGround) r.airTime = 0
    r.vel.y = Math.max(0, r.vel.y)
    r.onGround = true
  } else if (r.pos.y > 0.05) {
    r.onGround = false
  }
  if (r.pos.y > WALL_H - ROBOT_H) {
    r.pos.y = WALL_H - ROBOT_H
    r.vel.y = Math.min(0, r.vel.y)
  }

  const limX = HALF_W - ROBOT_R
  if (Math.abs(r.pos.x) > limX) {
    r.pos.x = Math.sign(r.pos.x) * limX
    r.vel.x *= -0.2
  }
  const inMouth = Math.abs(r.pos.x) < GOAL_HALF_W - ROBOT_R && r.pos.y < GOAL_H - ROBOT_H
  const limZ = inMouth ? HALF_L + GOAL_DEPTH - ROBOT_R - 0.5 : HALF_L - ROBOT_R
  if (Math.abs(r.pos.z) > limZ) {
    r.pos.z = Math.sign(r.pos.z) * limZ
    r.vel.z *= -0.2
  }
  if (Math.abs(r.pos.z) > HALF_L - ROBOT_R) {
    const limGX = GOAL_HALF_W - ROBOT_R
    if (Math.abs(r.pos.x) > limGX) r.pos.x = Math.sign(r.pos.x) * limGX
  }

  const speedH = Math.hypot(r.vel.x, r.vel.z)
  r.animPhase += speedH * dt * 0.62
}

function robotCollisions(w: World) {
  const rs = w.robots
  for (let i = 0; i < rs.length; i++) {
    for (let j = i + 1; j < rs.length; j++) {
      const a = rs[i]
      const b = rs[j]
      if (Math.abs(a.pos.y - b.pos.y) > 2.6) continue
      const dx = b.pos.x - a.pos.x
      const dz = b.pos.z - a.pos.z
      const d = Math.hypot(dx, dz)
      const min = ROBOT_R * 2
      if (d >= min || d < 1e-4) continue
      const nx = dx / d
      const nz = dz / d
      const overlap = (min - d) / 2
      a.pos.x -= nx * overlap
      a.pos.z -= nz * overlap
      b.pos.x += nx * overlap
      b.pos.z += nz * overlap

      const va = a.vel.x * nx + a.vel.z * nz
      const vb = b.vel.x * nx + b.vel.z * nz
      if (a.team !== b.team) {
        if (a.boosting && va > 17 && b.state !== 'stun') {
          demolish(w, b, nx, nz)
          continue
        }
        if (b.boosting && -vb > 17 && a.state !== 'stun') {
          demolish(w, a, -nx, -nz)
          continue
        }
        if (a.state === 'slide' && b.state !== 'stun') stunFromTackle(w, b, a)
        else if (b.state === 'slide' && a.state !== 'stun') stunFromTackle(w, a, b)
      }
      const rel = va - vb
      if (rel > 0) {
        const imp = rel * 0.55
        a.vel.x -= nx * imp
        a.vel.z -= nz * imp
        b.vel.x += nx * imp
        b.vel.z += nz * imp
      }
    }
  }
}

function demolish(w: World, victim: Robot, nx: number, nz: number) {
  victim.state = 'stun'
  victim.stateTime = 1.4
  victim.vel.set(nx * 16, 11, nz * 16)
  victim.onGround = false
  if (w.possessor === victim.id) looseBall(w, nx * 8, 6, nz * 8)
  w.shake = Math.max(w.shake, 0.6)
  w.events.push({ type: 'demo', pos: victim.pos.clone(), team: victim.team })
}

function stunFromTackle(w: World, victim: Robot, tackler: Robot) {
  victim.state = 'stun'
  victim.stateTime = 0.75
  victim.vel.x = tackler.vel.x * 0.4
  victim.vel.z = tackler.vel.z * 0.4
  if (w.possessor === victim.id) {
    const f = forwardOf(tackler)
    looseBall(w, f.x * 12, 3.5, f.z * 12)
  }
}

function looseBall(w: World, vx: number, vy: number, vz: number) {
  const holder = w.robots[w.possessor]
  if (holder) {
    holder.grabCooldown = 0.6
    holder.holdTime = 0
  }
  w.possessor = -1
  w.ball.vel.set(vx, vy, vz)
}

function segmentCollide(ball: Vector3, vel: Vector3, a: Vector3, b: Vector3, radius: number, restitution: number) {
  tmpA.subVectors(b, a)
  const len2 = tmpA.lengthSq()
  tmpB.subVectors(ball, a)
  const t = Math.max(0, Math.min(1, tmpB.dot(tmpA) / len2))
  tmpN.copy(a).addScaledVector(tmpA, t)
  tmpN.subVectors(ball, tmpN)
  const dist = tmpN.length()
  const min = BALL_R + radius
  if (dist >= min || dist < 1e-5) return false
  tmpN.divideScalar(dist)
  ball.addScaledVector(tmpN, min - dist)
  const vn = vel.dot(tmpN)
  if (vn < 0) vel.addScaledVector(tmpN, -(1 + restitution) * vn)
  return vn < -4
}

const postSegs = (() => {
  const segs: [Vector3, Vector3][] = []
  for (const s of [-1, 1]) {
    const z = s * HALF_L
    segs.push([new Vector3(-GOAL_HALF_W, 0, z), new Vector3(-GOAL_HALF_W, GOAL_H, z)])
    segs.push([new Vector3(GOAL_HALF_W, 0, z), new Vector3(GOAL_HALF_W, GOAL_H, z)])
    segs.push([new Vector3(-GOAL_HALF_W, GOAL_H, z), new Vector3(GOAL_HALF_W, GOAL_H, z)])
  }
  return segs
})()

function ballPhysics(w: World, dt: number) {
  const b = w.ball
  const p = b.pos
  const v = b.vel

  if (w.possessor >= 0) {
    const r = w.robots[w.possessor]
    const f = forwardOf(r)
    if (r.role === 'keeper' && (p.y > 1.4 || r.holdTime > 0)) {
      r.holdTime += dt
      p.set(r.pos.x + f.x * 1.1, r.pos.y + 1.9, r.pos.z + f.z * 1.1)
      v.copy(r.vel)
      return
    }
    if (!r.onGround || r.state === 'stun') {
      looseBall(w, r.vel.x, r.vel.y, r.vel.z)
    } else {
      const sp = Math.hypot(r.vel.x, r.vel.z)
      const touch = 1.55 + Math.max(0, Math.sin(r.animPhase * 0.5)) * Math.min(0.9, sp / 18)
      const tx = r.pos.x + f.x * touch
      const tz = r.pos.z + f.z * touch
      v.x = r.vel.x + (tx - p.x) * 14
      v.z = r.vel.z + (tz - p.z) * 14
      v.y = 0
      p.x += v.x * dt
      p.z += v.z * dt
      p.y = BALL_R
      if (Math.hypot(p.x - r.pos.x, p.z - r.pos.z) > 4) looseBall(w, v.x, 0, v.z)
      clampBallWalls(w)
      return
    }
  }

  v.y -= GRAVITY * dt
  v.multiplyScalar(1 - 0.12 * dt)
  p.addScaledVector(v, dt)

  if (p.y < BALL_R) {
    p.y = BALL_R
    if (v.y < -3) {
      if (v.y < -8) w.events.push({ type: 'bounce', pos: p.clone(), power: Math.min(1, -v.y / 30) })
      v.y = -v.y * 0.62
    } else v.y = 0
    v.x *= 1 - 0.6 * dt
    v.z *= 1 - 0.6 * dt
  }
  if (p.y > WALL_H - BALL_R) {
    p.y = WALL_H - BALL_R
    v.y = -Math.abs(v.y) * 0.7
  }

  for (const [a, c] of postSegs) {
    if (segmentCollide(p, v, a, c, POST_R, 0.75)) {
      w.events.push({ type: 'post', pos: p.clone() })
      w.shake = Math.max(w.shake, 0.3)
    }
  }
  clampBallWalls(w)
}

function clampBallWalls(w: World) {
  const p = w.ball.pos
  const v = w.ball.vel
  const limX = HALF_W - BALL_R
  if (Math.abs(p.x) > limX) {
    p.x = Math.sign(p.x) * limX
    if (Math.abs(v.x) > 6) w.events.push({ type: 'bounce', pos: p.clone(), power: Math.min(1, Math.abs(v.x) / 40) })
    v.x = -v.x * 0.72
  }
  const inGoal = Math.abs(p.z) > HALF_L - BALL_R
  if (inGoal) {
    const mouth = Math.abs(p.x) < GOAL_HALF_W - BALL_R * 0.4 && p.y < GOAL_H - BALL_R * 0.4
    if (!mouth && Math.abs(p.z) < HALF_L + 0.1) {
      p.z = Math.sign(p.z) * (HALF_L - BALL_R)
      if (Math.abs(v.z) > 6) w.events.push({ type: 'bounce', pos: p.clone(), power: Math.min(1, Math.abs(v.z) / 40) })
      v.z = -v.z * 0.72
    } else if (mouth || Math.abs(p.z) >= HALF_L + 0.1) {
      const gx = GOAL_HALF_W - BALL_R
      if (Math.abs(p.x) > gx) {
        p.x = Math.sign(p.x) * gx
        v.x *= -0.3
      }
      if (p.y > GOAL_H - BALL_R) {
        p.y = GOAL_H - BALL_R
        v.y = -Math.abs(v.y) * 0.3
      }
      const back = HALF_L + GOAL_DEPTH - BALL_R
      if (Math.abs(p.z) > back) {
        p.z = Math.sign(p.z) * back
        v.z *= -0.2
        v.x *= 0.5
      }
    }
  }
}

function ballRobotCollisions(w: World) {
  const b = w.ball
  for (const r of w.robots) {
    if (w.possessor === r.id) continue
    const low = r.state === 'slide' ? 0.4 : 0.7
    const high = r.state === 'slide' ? 1.2 : 2.7
    tmpA.set(r.pos.x, r.pos.y + low, r.pos.z)
    tmpB.set(r.pos.x, r.pos.y + high, r.pos.z)
    tmpB.sub(tmpA)
    const t = Math.max(0, Math.min(1, (b.pos.y - tmpA.y) / tmpB.y))
    const cx = r.pos.x
    const cy = tmpA.y + tmpB.y * t
    const cz = r.pos.z
    tmpN.set(b.pos.x - cx, b.pos.y - cy, b.pos.z - cz)
    const d = tmpN.length()
    const min = BALL_R + ROBOT_R
    if (d >= min || d < 1e-5) continue
    tmpN.divideScalar(d)
    b.pos.addScaledVector(tmpN, min - d)
    const rvx = b.vel.x - r.vel.x
    const rvy = b.vel.y - r.vel.y
    const rvz = b.vel.z - r.vel.z
    const vn = rvx * tmpN.x + rvy * tmpN.y + rvz * tmpN.z
    if (vn < 0) {
      const e = 0.45
      b.vel.x -= (1 + e) * vn * tmpN.x
      b.vel.y -= (1 + e) * vn * tmpN.y
      b.vel.z -= (1 + e) * vn * tmpN.z
      const hit = -vn
      if (hit > 8) {
        b.vel.addScaledVector(tmpN, hit * 0.25)
        w.events.push({ type: 'kick', pos: b.pos.clone(), team: r.team, power: Math.min(1, hit / 30) })
      }
      b.lastTouchTeam = r.team
      b.lastTouchId = r.id
    }
    if (w.possessor >= 0 && w.robots[w.possessor].team !== r.team) {
      // contact with dribbled ball handled by steal logic
    }
  }
}

function possession(w: World, dt: number) {
  const b = w.ball
  const diff = DIFFICULTY[w.difficulty]

  if (w.possessor >= 0) {
    const holder = w.robots[w.possessor]
    if (holder.role === 'keeper' && holder.holdTime > 0) return
    if (holder.state === 'skill') return
    for (const r of w.robots) {
      if (r.team === holder.team || r.state !== 'normal' || !r.onGround || r.grabCooldown > 0) continue
      const d = Math.hypot(b.pos.x - r.pos.x, b.pos.z - r.pos.z)
      if (d < 1.9) {
        const rate = r.id === w.controlled ? 1.6 : diff.steal
        if (Math.random() < rate * dt) {
          holder.grabCooldown = 0.7
          if (Math.random() < 0.55) {
            w.possessor = r.id
            r.receiveTimer = 0
            w.events.push({ type: 'tackle', pos: b.pos.clone(), team: r.team })
          } else {
            const f = forwardOf(r)
            looseBall(w, f.x * 9 + (Math.random() - 0.5) * 6, 2.5, f.z * 9)
            holder.grabCooldown = 0.7
          }
          return
        }
      }
    }
    return
  }

  let best: Robot | null = null
  let bestD = Infinity
  for (const r of w.robots) {
    if (r.grabCooldown > 0 || r.state === 'stun' || r.state === 'slide') continue
    const s = attackDir(r.team)
    const ownZ = -s * HALF_L
    const inBox = r.role === 'keeper' && Math.abs(r.pos.z - ownZ) < 17 && Math.abs(r.pos.x) < 20
    const rel = Math.hypot(b.vel.x - r.vel.x, b.vel.y - r.vel.y, b.vel.z - r.vel.z)
    if (inBox) {
      tmpA.set(r.pos.x, r.pos.y + 1.8, r.pos.z)
      const d = tmpA.distanceTo(b.pos)
      if (d < 2.7 && rel < diff.catchSpeed + (r.team === 0 && !w.demo ? 4 : 0) && d < bestD) {
        best = r
        bestD = d
      }
      continue
    }
    if (!r.onGround || b.pos.y > 2.1) continue
    const d = Math.hypot(b.pos.x - r.pos.x, b.pos.z - r.pos.z)
    const relH = Math.hypot(b.vel.x - r.vel.x, b.vel.z - r.vel.z)
    const limit = r.receiveTimer > 0 ? 36 : 24
    if (d < 2.45 && relH < limit && d < bestD) {
      best = r
      bestD = d
    }
  }
  if (best) {
    w.possessor = best.id
    best.holdTime = 0
    best.aimX = (Math.random() < 0.5 ? -1 : 1) * GOAL_HALF_W * (0.5 + Math.random() * 0.35)
    b.lastTouchTeam = best.team
    b.lastTouchId = best.id
    if (best.role === 'keeper' && b.pos.y > 1.4) {
      best.holdTime = 0.001
      w.events.push({ type: 'catch', pos: b.pos.clone(), team: best.team })
    }
    if (!w.demo && best.team === 0 && best.role !== 'keeper') w.controlled = best.id
  }
}

function pads(w: World, dt: number) {
  for (const p of w.pads) {
    if (!p.active) {
      p.timer -= dt
      if (p.timer <= 0) p.active = true
      continue
    }
    for (const r of w.robots) {
      if (r.pos.y > 1) continue
      const d = Math.hypot(r.pos.x - p.pos.x, r.pos.z - p.pos.z)
      if (d < (p.big ? 2.4 : 1.8) && r.boost < 100) {
        r.boost = Math.min(100, r.boost + (p.big ? 100 : 25))
        p.active = false
        p.timer = p.big ? 9 : 4.5
        if (r.id === w.controlled) w.events.push({ type: 'pad', pos: p.pos.clone() })
        break
      }
    }
  }
}

function processQueued(w: World, dt: number) {
  for (const r of w.robots) {
    const q = r.queued
    if (!q) continue
    q.t -= dt
    if (q.t <= 0) {
      r.queued = null
      continue
    }
    if (!reachOf(w, r)) continue
    if (q.type === 'shot') shoot(w, r, q.charge, q.aimX, q.aimZ)
    else {
      const recv = pass(w, r, q.type === 'lob', q.aimX, q.aimZ)
      if (recv && !w.demo && r.id === w.controlled && recv.role !== 'keeper') w.controlled = recv.id
    }
  }
}

function checkGoal(w: World) {
  if (w.phase !== 'playing') return
  const p = w.ball.pos
  if (Math.abs(p.z) > HALF_L + BALL_R * 0.9 && Math.abs(p.x) < GOAL_HALF_W && p.y < GOAL_H) {
    const scoringTeam = p.z > 0 ? 0 : 1
    w.score[scoringTeam]++
    const scorer = w.robots[w.ball.lastTouchId]
    w.lastScorer = {
      team: scoringTeam,
      name: scorer ? (scorer.team === scoringTeam ? scorer.name : `OWN GOAL · ${scorer.name}`) : 'UNKNOWN',
    }
    w.phase = 'goal'
    w.phaseTime = 0
    w.kickoffTeam = scoringTeam === 0 ? 1 : 0
    w.goalPos.set(p.x, p.y, Math.sign(p.z) * HALF_L)
    w.shake = 1
    w.events.push({ type: 'goal', pos: w.goalPos.clone(), team: scoringTeam })
  }
}

export function simStep(w: World, dt: number) {
  const frozen = w.phase === 'kickoff' || w.phase === 'ended'
  if (frozen) {
    for (const r of w.robots) {
      r.vel.set(0, 0, 0)
      r.thrust *= 0.9
      r.kickAnim = Math.max(0, r.kickAnim - dt * 3)
    }
    return
  }
  for (const r of w.robots) moveRobot(w, r, dt)
  robotCollisions(w)
  processQueued(w, dt)
  ballPhysics(w, dt)
  ballRobotCollisions(w)
  possession(w, dt)
  pads(w, dt)
  checkGoal(w)
}

export function predictBall(w: World, t: number, out: Vector3) {
  const b = w.ball
  if (w.possessor >= 0) {
    const r = w.robots[w.possessor]
    return out.set(b.pos.x + r.vel.x * t, b.pos.y, b.pos.z + r.vel.z * t)
  }
  let px = b.pos.x
  let py = b.pos.y
  let pz = b.pos.z
  let vx = b.vel.x
  let vy = b.vel.y
  let vz = b.vel.z
  const step = 1 / 30
  for (let s = 0; s < t; s += step) {
    vy -= GRAVITY * step
    px += vx * step
    py += vy * step
    pz += vz * step
    if (py < BALL_R) {
      py = BALL_R
      vy = Math.abs(vy) > 3 ? -vy * 0.62 : 0
      vx *= 0.98
      vz *= 0.98
    }
    if (Math.abs(px) > HALF_W - BALL_R) {
      px = Math.sign(px) * (HALF_W - BALL_R)
      vx = -vx * 0.72
    }
    if (Math.abs(pz) > HALF_L - BALL_R && !(Math.abs(px) < GOAL_HALF_W && py < GOAL_H)) {
      pz = Math.sign(pz) * (HALF_L - BALL_R)
      vz = -vz * 0.72
    }
  }
  return out.set(px, py, pz)
}

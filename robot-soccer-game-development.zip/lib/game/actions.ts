import { Vector3 } from 'three'
import { GOAL_HALF_W, GRAVITY, HALF_L, HALF_W } from './constants'
import { attackDir, forwardOf, type Robot, type World } from './world'

const tmp = new Vector3()

export type Reach = 'foot' | 'head' | 'held' | null

export function reachOf(w: World, r: Robot): Reach {
  if (w.possessor === r.id) return r.role === 'keeper' && w.ball.pos.y > 1.5 ? 'held' : 'foot'
  if (r.state === 'stun') return null
  const b = w.ball.pos
  const f = forwardOf(r)
  tmp.set(r.pos.x + f.x * 1.0, r.pos.y + 0.7, r.pos.z + f.z * 1.0)
  if (tmp.distanceTo(b) < 2.7) return 'foot'
  tmp.set(r.pos.x + f.x * 0.4, r.pos.y + 3.0, r.pos.z + f.z * 0.4)
  if (tmp.distanceTo(b) < 2.6) return 'head'
  return null
}

function normalizeAim(r: Robot, aimX: number, aimZ: number) {
  const len = Math.hypot(aimX, aimZ)
  if (len > 0.2) return { x: aimX / len, z: aimZ / len }
  return forwardOf(r)
}

function release(w: World, r: Robot, power: number) {
  w.possessor = -1
  r.kickCooldown = 0.32
  r.grabCooldown = 0.45
  r.kickAnim = 1
  r.holdTime = 0
  r.queued = null
  w.ball.lastTouchTeam = r.team
  w.ball.lastTouchId = r.id
  w.events.push({ type: 'kick', pos: w.ball.pos.clone(), team: r.team, power })
  if (power > 0.75) w.shake = Math.max(w.shake, 0.25)
}

export function shoot(w: World, r: Robot, charge: number, aimX: number, aimZ: number) {
  const reach = reachOf(w, r)
  if (!reach || r.kickCooldown > 0) return false
  const b = w.ball
  let dir = normalizeAim(r, aimX, aimZ)
  const s = attackDir(r.team)
  const goalZ = s * HALF_L
  if (dir.z * s > 0.15) {
    const t = (goalZ - b.pos.z) / dir.z
    const hitX = b.pos.x + dir.x * t
    const targetX = Math.max(-GOAL_HALF_W + 1.3, Math.min(GOAL_HALF_W - 1.3, hitX))
    const tx = targetX - b.pos.x
    const tz = goalZ - b.pos.z
    const tl = Math.hypot(tx, tz) || 1
    const assist = Math.abs(goalZ - b.pos.z) < 60 ? 0.78 : 0.4
    const nx = dir.x * (1 - assist) + (tx / tl) * assist
    const nz = dir.z * (1 - assist) + (tz / tl) * assist
    const nl = Math.hypot(nx, nz) || 1
    dir = { x: nx / nl, z: nz / nl }
  }
  const c = Math.max(0, Math.min(1, charge))
  const speed = 24 + c * 32
  let vy = reach === 'head' ? 0.5 + c * 3.5 : 1.8 + c * c * 9.5
  if (reach === 'foot' && b.pos.y > 2) vy *= 0.55
  b.vel.set(dir.x * speed, vy, dir.z * speed)
  r.facing = Math.atan2(dir.x, dir.z)
  release(w, r, 0.35 + c * 0.65)
  return true
}

export function pickReceiver(w: World, r: Robot, aimX: number, aimZ: number) {
  const dir = normalizeAim(r, aimX, aimZ)
  let best: Robot | null = null
  let bestScore = -Infinity
  for (const t of w.robots) {
    if (t.team !== r.team || t.id === r.id) continue
    const dx = t.pos.x - r.pos.x
    const dz = t.pos.z - r.pos.z
    const d = Math.hypot(dx, dz) || 1
    const align = (dx * dir.x + dz * dir.z) / d
    let score = align * 2.4 - d / 45
    if (t.role === 'keeper') score -= 1.2
    for (const o of w.robots) {
      if (o.team === r.team) continue
      const ox = o.pos.x - r.pos.x
      const oz = o.pos.z - r.pos.z
      const along = (ox * dx + oz * dz) / d
      if (along > 0 && along < d) {
        const perp = Math.abs(ox * dz - oz * dx) / d
        if (perp < 2.5) score -= 0.8
      }
    }
    if (score > bestScore) {
      bestScore = score
      best = t
    }
  }
  return best
}

export function pass(w: World, r: Robot, lob: boolean, aimX: number, aimZ: number) {
  const reach = reachOf(w, r)
  if (!reach || r.kickCooldown > 0) return null
  const receiver = pickReceiver(w, r, aimX, aimZ)
  const b = w.ball
  if (!receiver) {
    const f = normalizeAim(r, aimX, aimZ)
    b.vel.set(f.x * 22, lob ? 12 : 0.5, f.z * 22)
    release(w, r, 0.3)
    return null
  }
  const s = attackDir(r.team)
  const lead = lob ? 0.9 : 0.45
  let tx = receiver.pos.x + receiver.vel.x * lead
  let tz = receiver.pos.z + receiver.vel.z * lead + (lob ? s * 3 : 0)
  tx = Math.max(-HALF_W + 3, Math.min(HALF_W - 3, tx))
  tz = Math.max(-HALF_L + 3, Math.min(HALF_L - 3, tz))
  const dx = tx - b.pos.x
  const dz = tz - b.pos.z
  const d = Math.hypot(dx, dz) || 1
  if (lob) {
    const T = Math.max(0.75, Math.min(1.7, d / 24))
    const h = (d / T) * 1.06
    b.vel.set((dx / d) * h, (GRAVITY * T) / 2 - (b.pos.y - 1.2) / T, (dz / d) * h)
  } else {
    const speed = Math.max(16, Math.min(36, d * 1.05 + 9))
    b.vel.set((dx / d) * speed, 0.6, (dz / d) * speed)
  }
  r.facing = Math.atan2(dx, dz)
  receiver.receiveTimer = 1.6
  release(w, r, lob ? 0.4 : 0.3)
  return receiver
}

export function tackle(w: World, r: Robot, dirX?: number, dirZ?: number) {
  if (r.state !== 'normal' || r.tackleCooldown > 0 || !r.onGround || w.possessor === r.id) return false
  if (dirX !== undefined && dirZ !== undefined && Math.hypot(dirX, dirZ) > 0.1) r.facing = Math.atan2(dirX, dirZ)
  const f = forwardOf(r)
  r.state = 'slide'
  r.stateTime = 0.5
  r.vel.x = f.x * 22
  r.vel.z = f.z * 22
  r.tackleCooldown = 1.1
  w.events.push({ type: 'tackle', pos: r.pos.clone(), team: r.team })
  return true
}

export function skill(w: World, r: Robot) {
  if (w.possessor !== r.id || r.skillCooldown > 0 || r.state !== 'normal') return false
  const f = forwardOf(r)
  r.state = 'skill'
  r.stateTime = 0.55
  r.vel.x = f.x * 18
  r.vel.z = f.z * 18
  r.skillCooldown = 1.3
  return true
}

export function jump(r: Robot) {
  if (!r.onGround || r.state === 'stun' || r.state === 'slide') return false
  r.vel.y = 13
  r.onGround = false
  r.airTime = 0
  return true
}

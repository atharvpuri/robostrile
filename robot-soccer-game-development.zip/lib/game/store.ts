import { create } from 'zustand'
import type { Difficulty } from './constants'

export type Screen = 'menu' | 'playing' | 'paused' | 'ended'
export type Quality = 'high' | 'performance'

export interface Hud {
  score: [number, number]
  clock: number
  overtime: boolean
  boost: number
  charge: number
  controlledName: string
  controlledNumber: number
  hasBall: boolean
  message: string
  sub: string
  messageTeam: number
}

interface GameStore {
  screen: Screen
  difficulty: Difficulty
  minutes: number
  quality: Quality
  sound: boolean
  matchId: number
  hud: Hud
  setScreen: (s: Screen) => void
  setDifficulty: (d: Difficulty) => void
  setMinutes: (m: number) => void
  setQuality: (q: Quality) => void
  setSound: (s: boolean) => void
  startMatch: () => void
  setHud: (h: Partial<Hud>) => void
}

export const useGame = create<GameStore>((set) => ({
  screen: 'menu',
  difficulty: 'pro',
  minutes: 3,
  quality: 'high',
  sound: true,
  matchId: 0,
  hud: {
    score: [0, 0],
    clock: 180,
    overtime: false,
    boost: 0,
    charge: 0,
    controlledName: '',
    controlledNumber: 0,
    hasBall: false,
    message: '',
    sub: '',
    messageTeam: -1,
  },
  setScreen: (screen) => set({ screen }),
  setDifficulty: (difficulty) => set({ difficulty }),
  setMinutes: (minutes) => set({ minutes }),
  setQuality: (quality) => set({ quality }),
  setSound: (sound) => set({ sound }),
  startMatch: () => set((s) => ({ screen: 'playing', matchId: s.matchId + 1 })),
  setHud: (h) => set((s) => ({ hud: { ...s.hud, ...h } })),
}))

export const input = {
  moveX: 0,
  moveY: 0,
  boost: false,
  jump: false,
  shoot: false,
  pass: false,
  lob: false,
  tackle: false,
  switch: false,
}

export type InputKey = Exclude<keyof typeof input, 'moveX' | 'moveY'>

export const keys = new Set<string>()

export function readKeyboard() {
  let x = 0
  let y = 0
  if (keys.has('KeyA') || keys.has('ArrowLeft')) x -= 1
  if (keys.has('KeyD') || keys.has('ArrowRight')) x += 1
  if (keys.has('KeyW') || keys.has('ArrowUp')) y += 1
  if (keys.has('KeyS') || keys.has('ArrowDown')) y -= 1
  return {
    x,
    y,
    boost: keys.has('ShiftLeft') || keys.has('ShiftRight'),
    jump: keys.has('Space'),
    shoot: keys.has('KeyJ'),
    pass: keys.has('KeyK'),
    lob: keys.has('KeyL'),
    tackle: keys.has('KeyI'),
    switch: keys.has('KeyQ'),
  }
}

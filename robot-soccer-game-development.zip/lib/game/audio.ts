let ctx: AudioContext | null = null
let master: GainNode | null = null
let crowdGain: GainNode | null = null
let noiseBuffer: AudioBuffer | null = null
let enabled = true

export function setSoundEnabled(on: boolean) {
  enabled = on
  if (master) master.gain.value = on ? 0.8 : 0
}

export function ensureAudio() {
  if (typeof window === 'undefined') return
  if (!ctx) {
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext
    if (!AC) return
    ctx = new AC()
    master = ctx.createGain()
    master.gain.value = enabled ? 0.8 : 0
    master.connect(ctx.destination)
    noiseBuffer = ctx.createBuffer(1, ctx.sampleRate * 2, ctx.sampleRate)
    const data = noiseBuffer.getChannelData(0)
    for (let i = 0; i < data.length; i++) data[i] = Math.random() * 2 - 1
    startCrowd()
  }
  if (ctx.state === 'suspended') ctx.resume()
}

function startCrowd() {
  if (!ctx || !master || !noiseBuffer) return
  const src = ctx.createBufferSource()
  src.buffer = noiseBuffer
  src.loop = true
  const bp = ctx.createBiquadFilter()
  bp.type = 'bandpass'
  bp.frequency.value = 700
  bp.Q.value = 0.6
  crowdGain = ctx.createGain()
  crowdGain.gain.value = 0.05
  src.connect(bp).connect(crowdGain).connect(master)
  src.start()
}

function noiseBurst(duration: number, freq: number, gain: number, type: BiquadFilterType = 'lowpass') {
  if (!ctx || !master || !noiseBuffer) return
  const t = ctx.currentTime
  const src = ctx.createBufferSource()
  src.buffer = noiseBuffer
  const f = ctx.createBiquadFilter()
  f.type = type
  f.frequency.value = freq
  const g = ctx.createGain()
  g.gain.setValueAtTime(gain, t)
  g.gain.exponentialRampToValueAtTime(0.001, t + duration)
  src.connect(f).connect(g).connect(master)
  src.start(t, Math.random())
  src.stop(t + duration)
}

function tone(freq: number, duration: number, gain: number, type: OscillatorType = 'sine', slideTo?: number, delay = 0) {
  if (!ctx || !master) return
  const t = ctx.currentTime + delay
  const o = ctx.createOscillator()
  o.type = type
  o.frequency.setValueAtTime(freq, t)
  if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, t + duration)
  const g = ctx.createGain()
  g.gain.setValueAtTime(0.0001, t)
  g.gain.exponentialRampToValueAtTime(gain, t + 0.01)
  g.gain.exponentialRampToValueAtTime(0.0001, t + duration)
  o.connect(g).connect(master)
  o.start(t)
  o.stop(t + duration + 0.05)
}

export const sfx = {
  kick(power = 0.5) {
    tone(140 + power * 60, 0.14, 0.35 + power * 0.4, 'sine', 50)
    noiseBurst(0.08, 2400, 0.15 + power * 0.25)
  },
  bounce(power = 0.5) {
    tone(110, 0.1, 0.15 + power * 0.25, 'sine', 60)
  },
  post() {
    tone(880, 0.6, 0.25, 'triangle', 860)
    tone(1320, 0.5, 0.12, 'sine', 1300)
  },
  whistle() {
    tone(2600, 0.18, 0.18, 'square', 2500)
    tone(2600, 0.45, 0.18, 'square', 2450, 0.22)
  },
  pad() {
    tone(520, 0.18, 0.15, 'sine', 1040)
  },
  tackle() {
    noiseBurst(0.25, 900, 0.3)
  },
  demo() {
    noiseBurst(0.6, 600, 0.6)
    tone(90, 0.5, 0.5, 'sawtooth', 40)
  },
  catch() {
    tone(200, 0.12, 0.3, 'sine', 120)
  },
  goal() {
    if (!ctx || !crowdGain) return
    tone(220, 1.6, 0.35, 'sawtooth', 210)
    tone(277, 1.6, 0.25, 'sawtooth', 270)
    tone(330, 1.6, 0.25, 'sawtooth', 325)
    const t = ctx.currentTime
    crowdGain.gain.cancelScheduledValues(t)
    crowdGain.gain.setValueAtTime(0.05, t)
    crowdGain.gain.linearRampToValueAtTime(0.32, t + 0.3)
    crowdGain.gain.linearRampToValueAtTime(0.05, t + 4)
  },
  countdown(final = false) {
    tone(final ? 880 : 520, final ? 0.4 : 0.15, 0.25, 'sine')
  },
}

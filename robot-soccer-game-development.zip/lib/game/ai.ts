import { Vector3 } from 'three'
import { DIFFICULTY, GOAL_HALF_W, GRAVITY, HALF_L, HALF_W } from './constants'
import { jump, pass, pickReceiver, reachOf, shoot, skill, tackle } from './actions'
import { predictBall } from './sim'
import { attackDir, forwardOf, type Robot, type World } from './world'

const pred = new Vector3()

function clampField(t: { x: number; z: number }) {
  t.x = Math.max(-HALF_W + 2, Math.min(HALF_W - 2, t.x))
  t.z = Math.max(-HALF_L + 2, Math.min(HALF_L - 2, t.z))
  return t
}

function chaserOf(w: World, team: number) {
  let best = -1
  let bestT = Infinity
  const b = w.ball.pos
  const s = attackDir(team)
  for (const r of w.robots) {
    if (r.team !== team || r.role === 'keeper' || r.state === 'stun') continue
    const d = Math.hypot(b.x - r.pos.x, b.z - r.pos.z)
    const behind = (b.z - r.pos.z) * s < 0 ? 4 : 0
    const t = d + behind
    if (t < bestT) {
      bestT = t
      best = r.id
    }
  }
  return best
}

function nearestOpponentAhead(w: World, r: Robot) {
  const f = forwardOf(r)
  let best: Robot | null = null
  let bestD = 8
  for (const o of w.robots) {
    if (o.team === r.team || o.state === 'stun') continue
    const dx = o.pos.x - r.pos.x
    const dz = o.pos.z - r.pos.z
    const d = Math.hypot(dx, dz)
    if (d < bestD && (dx * f.x + dz * f.z) / (d || 1) > 0.25) {
      best = o
      bestD = d
    }
  }
  return best ? { robot: best, dist: bestD } : null
}

export function aiThink(w: World, r: Robot, dt: number) {
  const it = r.intent
  it.mx = 0
  it.mz = 0
  it.sprint = false
  it.jump = false
  if (r.state === 'stun') return

  const diff = DIFFICULTY[w.difficulty]
  const b = w.ball
  const s = attackDir(r.team)
  const attackZ = s * HALF_L
  const ownZ = -s * HALF_L
  const poss = w.possessor
  const possTeam = poss >= 0 ? w.robots[poss].team : -1

  r.aiThink -= dt
  const think = r.aiThink <= 0
  if (think) r.aiThink = diff.think * (0.6 + Math.random() * 0.8)

  const target = { x: r.pos.x, z: r.pos.z }
  let arrive = 2.5

  if (poss === r.id) {
    if (r.role === 'keeper') {
      if (think && (r.holdTime > 0.8 || r.holdTime === 0)) {
        const recv = pickReceiver(w, r, 0, s)
        if (recv) pass(w, r, Math.random() < 0.6, recv.pos.x - r.pos.x, recv.pos.z - r.pos.z)
        else shoot(w, r, 0.7, 0, s)
      }
      target.x = r.pos.x
      target.z = r.pos.z
    } else {
      const distGoal = Math.hypot(b.pos.x, attackZ - b.pos.z)
      target.x = r.aimX * 0.6
      target.z = attackZ
      const threat = nearestOpponentAhead(w, r)
      if (threat && threat.dist < 7) {
        const side = Math.sign(r.pos.x - threat.robot.pos.x) || (Math.random() < 0.5 ? -1 : 1)
        target.x = r.pos.x + side * 10
        target.z = r.pos.z + s * 7
      }
      it.sprint = r.boost > 20 && (!threat || threat.dist > 5)
      if (think) {
        const err = (Math.random() - 0.5) * diff.aimError * 10
        if (distGoal < 34 && (distGoal < 20 || !threat || Math.random() < 0.4)) {
          const charge = Math.max(0.2, Math.min(0.85, 0.15 + distGoal / 42 + (Math.random() - 0.5) * diff.aimError))
          shoot(w, r, charge, r.aimX + err - b.pos.x, attackZ - b.pos.z)
          return
        }
        if (threat && threat.dist < 4.5) {
          const roll = Math.random()
          if (roll < 0.45) {
            const recv = pass(w, r, Math.random() < 0.3, 0, s)
            if (recv) return
          } else if (roll < 0.75) {
            skill(w, r)
          }
        } else if (Math.random() < 0.06) {
          for (const t of w.robots) {
            if (t.team !== r.team || t.id === r.id || t.role === 'keeper') continue
            if ((t.pos.z - r.pos.z) * s > 10 && Math.abs(t.pos.z - attackZ) < 35) {
              pass(w, r, false, t.pos.x - r.pos.x, t.pos.z - r.pos.z)
              return
            }
          }
        }
      }
    }
  } else if (r.role === 'keeper') {
    let kx = Math.max(-GOAL_HALF_W + 1.5, Math.min(GOAL_HALF_W - 1.5, b.pos.x * 0.35))
    let kz = ownZ + s * 2.6
    const towardGoal = b.vel.z * s < -6 && Math.abs(b.pos.z - ownZ) < 34 && possTeam !== r.team
    if (towardGoal && poss < 0) {
      const t = (kz - b.pos.z) / b.vel.z
      if (t > 0 && t < 1.6) {
        const px = b.pos.x + b.vel.x * t
        const py = b.pos.y + b.vel.y * t - 0.5 * GRAVITY * t * t
        kx = Math.max(-GOAL_HALF_W - 1, Math.min(GOAL_HALF_W + 1, px))
        it.sprint = true
        if (py > 3.4 && t < 0.42) it.jump = true
        if (it.jump && think) jump(r)
        if (Math.abs(px - r.pos.x) > 3.2 && t < 0.38 && py < 3.5 && think && Math.random() < diff.tackle + 0.15)
          tackle(w, r, px - r.pos.x, 0)
      }
    }
    if (think) r.aimX = kx
    kx = r.aimX
    const loose = poss < 0
    const ballInBox = Math.abs(b.pos.z - ownZ) < 15 && Math.abs(b.pos.x) < 16
    if (ballInBox && (loose || possTeam !== r.team) && b.pos.y < 3) {
      const closestOpp = w.robots
        .filter((o) => o.team !== r.team)
        .reduce((m, o) => Math.min(m, Math.hypot(o.pos.x - b.pos.x, o.pos.z - b.pos.z)), Infinity)
      const myD = Math.hypot(r.pos.x - b.pos.x, r.pos.z - b.pos.z)
      if (myD < closestOpp + 2 || possTeam !== -1) {
        kx = b.pos.x
        kz = b.pos.z - s * 0.8
        it.sprint = myD > 4
        if (possTeam !== -1 && myD < 3.4 && think && Math.random() < diff.tackle) tackle(w, r, b.pos.x - r.pos.x, b.pos.z - r.pos.z)
      }
    }
    target.x = kx
    target.z = kz
    arrive = 1.2
  } else if (possTeam === r.team) {
    const carrier = w.robots[poss]
    if (r.role === 'striker') {
      const lane = carrier.pos.x > 0 ? -10 : 10
      target.x = lane
      target.z = carrier.pos.z + s * 12
      if ((target.z - attackZ) * s > -8) target.z = attackZ - s * 8
    } else {
      target.x = carrier.pos.x * 0.4 + (carrier.pos.x > 0 ? -6 : 6)
      target.z = carrier.pos.z - s * 11
    }
    it.sprint = Math.hypot(target.x - r.pos.x, target.z - r.pos.z) > 14 && r.boost > 40
  } else {
    const chaser = chaserOf(w, r.team)
    const iAmChaser = chaser === r.id
    const dist = Math.hypot(b.pos.x - r.pos.x, b.pos.z - r.pos.z)
    if (iAmChaser || r.receiveTimer > 0) {
      predictBall(w, Math.min(1.1, dist / 18), pred)
      target.x = pred.x - s * (poss < 0 ? 1.0 : 0)
      target.z = pred.z - s * (poss < 0 ? 1.2 : 0)
      arrive = 0.6
      it.sprint = r.boost > 8 && dist > 6
      if (possTeam !== -1 && possTeam !== r.team) {
        const carrier = w.robots[poss]
        const cd = Math.hypot(carrier.pos.x - r.pos.x, carrier.pos.z - r.pos.z)
        if (cd < 3.6 && think && Math.random() < diff.tackle) {
          tackle(w, r, b.pos.x - r.pos.x, b.pos.z - r.pos.z)
        }
      }
      if (poss < 0) {
        if (b.pos.y > 3 && dist < 7 && b.pos.y < 14) {
          it.jump = true
          if (r.onGround && (b.vel.y < 4 || dist < 3.5)) jump(r)
        }
        const reach = reachOf(w, r)
        if (reach && (reach === 'head' || b.pos.y > 2.1) && r.kickCooldown <= 0) {
          const nearGoal = Math.abs(attackZ - b.pos.z) < 32
          shoot(w, r, nearGoal ? 0.5 : 0.75, (r.aimX || 0) - b.pos.x, attackZ - b.pos.z)
        }
      }
    } else {
      if (r.role === 'defender') {
        target.x = b.pos.x * 0.6
        target.z = b.pos.z + (ownZ - b.pos.z) * 0.55
        if ((target.z - ownZ) * s < 8) target.z = ownZ + s * 8
      } else {
        target.x = b.pos.x * 0.5 + (r.team === 0 ? 8 : -8)
        target.z = b.pos.z - s * 5
      }
      it.sprint = Math.hypot(target.x - r.pos.x, target.z - r.pos.z) > 18 && r.boost > 50
    }
  }

  clampField(target)
  if (r.role === 'keeper') {
    target.z = Math.max(-HALF_L - 1, Math.min(HALF_L + 1, target.z))
  }
  const dx = target.x - r.pos.x
  const dz = target.z - r.pos.z
  const d = Math.hypot(dx, dz)
  if (d > 0.35) {
    const m = Math.min(1, d / arrive)
    it.mx = (dx / d) * m
    it.mz = (dz / d) * m
  } else if (r.role === 'keeper' || poss < 0) {
    const fx = b.pos.x - r.pos.x
    const fz = b.pos.z - r.pos.z
    r.facing += Math.atan2(Math.sin(Math.atan2(fx, fz) - r.facing), Math.cos(Math.atan2(fx, fz) - r.facing)) * Math.min(1, dt * 6)
  }
}

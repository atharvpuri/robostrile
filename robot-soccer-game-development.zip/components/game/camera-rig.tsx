'use client'

import { useFrame, useThree } from '@react-three/fiber'
import { useRef } from 'react'
import * as THREE from 'three'
import { HALF_L } from '@/lib/game/constants'
import { useGame } from '@/lib/game/store'
import { world } from '@/lib/game/world'

const desired = new THREE.Vector3()
const lookTarget = new THREE.Vector3()

export function CameraRig() {
  const camera = useThree((s) => s.camera) as THREE.PerspectiveCamera
  const look = useRef(new THREE.Vector3(0, 2, 0))
  const lastFov = useRef(0)
  const wasDemo = useRef(true)

  useFrame((state, delta) => {
    const w = world
    const dt = Math.min(delta, 0.05)
    const t = state.clock.elapsedTime
    const screen = useGame.getState().screen
    const aspect = state.size.width / state.size.height
    const portrait = aspect < 1
    const fov = portrait ? 74 : aspect < 1.5 ? 64 : 56
    if (fov !== lastFov.current) {
      camera.fov = fov
      camera.updateProjectionMatrix()
      lastFov.current = fov
    }

    const b = w.ball.pos
    let followRate = 4

    if (w.demo || screen === 'menu' || screen === 'ended') {
      const a = t * 0.08
      desired.set(Math.sin(a) * 62, 26 + Math.sin(t * 0.2) * 4, Math.cos(a) * 78)
      lookTarget.set(b.x * 0.5, 2, b.z * 0.5)
      followRate = 1.5
    } else if (w.phase === 'goal') {
      const side = Math.sign(w.goalPos.z) || 1
      const a = w.phaseTime * 0.35
      desired.set(Math.sin(a) * 20, 9 + w.phaseTime * 1.2, w.goalPos.z - side * (24 - w.phaseTime * 2))
      lookTarget.set(w.goalPos.x * 0.5, 3.5, w.goalPos.z)
      followRate = 2.5
    } else {
      const r = w.robots[w.controlled] ?? w.robots[2]
      const back = portrait ? 28 : 20
      const height = portrait ? 20 : 12.5
      desired.set(r.pos.x * 0.82, height + r.pos.y * 0.5, Math.max(-HALF_L - 12, r.pos.z - back))
      const ballPull = Math.min(0.45, 18 / (8 + r.pos.distanceTo(b)))
      lookTarget.set(
        THREE.MathUtils.lerp(r.pos.x, b.x, ballPull),
        2 + r.pos.y * 0.4,
        THREE.MathUtils.lerp(r.pos.z, b.z, ballPull) + 9,
      )
      if (w.phase === 'kickoff') {
        desired.y += 4
        desired.z -= 4
      }
    }

    if (wasDemo.current && !w.demo) {
      camera.position.copy(desired)
      look.current.copy(lookTarget)
    }
    wasDemo.current = w.demo
    const k = 1 - Math.exp(-followRate * dt)
    camera.position.lerp(desired, k)
    look.current.lerp(lookTarget, 1 - Math.exp(-6 * dt))

    if (w.shake > 0.001) {
      const s = w.shake * 0.6
      camera.position.x += (Math.random() - 0.5) * s
      camera.position.y += (Math.random() - 0.5) * s
      w.shake *= Math.exp(-5 * dt)
    }
    camera.lookAt(look.current)
  })

  return null
}

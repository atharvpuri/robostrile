'use client'

import { useFrame } from '@react-three/fiber'
import { useRef } from 'react'
import { aiThink } from '@/lib/game/ai'
import { jump, pass, reachOf, shoot, skill, tackle } from '@/lib/game/actions'
import { sfx } from '@/lib/game/audio'
import { SIM_DT, TEAMS } from '@/lib/game/constants'
import { fxBus } from '@/lib/game/fx-bus'
import { input, readKeyboard } from '@/lib/game/input'
import { simStep } from '@/lib/game/sim'
import { useGame } from '@/lib/game/store'
import { resetKickoff, world, type Robot } from '@/lib/game/world'

function vibrate(ms: number) {
  if (typeof navigator !== 'undefined' && 'vibrate' in navigator) navigator.vibrate?.(ms)
}

export function GameLoop() {
  const acc = useRef(0)
  const prev = useRef({ shoot: false, pass: false, lob: false, tackle: false, switch: false, jump: false })
  const charge = useRef(0)
  const hudTimer = useRef(0)
  const lastCount = useRef(-1)
  const overtimeAt = useRef(-10)
  const endedSent = useRef(false)

  useFrame((_, delta) => {
    const store = useGame.getState()
    const w = world
    if (store.screen === 'paused') return
    const dt = Math.min(delta, 1 / 20)
    w.time += dt

    const kb = readKeyboard()
    const moveX = Math.max(-1, Math.min(1, input.moveX + kb.x))
    const moveY = Math.max(-1, Math.min(1, input.moveY + kb.y))
    const btn = {
      boost: input.boost || kb.boost,
      jump: input.jump || kb.jump,
      shoot: input.shoot || kb.shoot,
      pass: input.pass || kb.pass,
      lob: input.lob || kb.lob,
      tackle: input.tackle || kb.tackle,
      switch: input.switch || kb.switch,
    }
    const pressed = (k: keyof typeof prev.current) => btn[k] && !prev.current[k]
    const playing = w.phase === 'playing'
    const human: Robot | null = !w.demo && w.controlled >= 0 ? w.robots[w.controlled] : null

    if (human) {
      const it = human.intent
      const len = Math.hypot(moveX, moveY)
      const n = len > 1 ? 1 / len : 1
      it.mx = -moveX * n
      it.mz = moveY * n
      it.sprint = btn.boost
      it.jump = btn.jump
      const aimX = len > 0.2 ? it.mx : 0
      const aimZ = len > 0.2 ? it.mz : 0

      if (playing) {
        if (pressed('jump')) jump(human)
        if (btn.shoot) charge.current = Math.min(1, charge.current + dt / 0.85)
        if (!btn.shoot && prev.current.shoot) {
          const c = charge.current
          if (!shoot(w, human, c, aimX, aimZ)) human.queued = { type: 'shot', charge: c, aimX, aimZ, t: 0.45 }
          charge.current = 0
        }
        for (const type of ['pass', 'lob'] as const) {
          if (pressed(type)) {
            if (reachOf(w, human)) {
              const recv = pass(w, human, type === 'lob', aimX, aimZ)
              if (recv && recv.role !== 'keeper') w.controlled = recv.id
            } else human.queued = { type, charge: 0, aimX, aimZ, t: 0.45 }
          }
        }
        if (pressed('tackle')) {
          if (w.possessor === human.id) skill(w, human)
          else tackle(w, human, aimX || undefined, aimZ || undefined)
        }
        if (pressed('switch')) {
          let best = -1
          let bestD = Infinity
          for (const r of w.robots) {
            if (r.team !== 0 || r.role === 'keeper' || r.id === human.id) continue
            const d = r.pos.distanceTo(w.ball.pos)
            if (d < bestD) {
              bestD = d
              best = r.id
            }
          }
          if (best >= 0) {
            human.intent.mx = 0
            human.intent.mz = 0
            human.intent.sprint = false
            w.controlled = best
          }
        }
      } else {
        charge.current = 0
      }
    }
    prev.current = { shoot: btn.shoot, pass: btn.pass, lob: btn.lob, tackle: btn.tackle, switch: btn.switch, jump: btn.jump }

    w.phaseTime += dt
    const kickoffLen = w.demo ? 1.6 : 3
    if (w.phase === 'kickoff') {
      const count = Math.ceil(kickoffLen - w.phaseTime)
      if (!w.demo && count !== lastCount.current && count > 0) {
        sfx.countdown(false)
        lastCount.current = count
      }
      if (w.phaseTime >= kickoffLen) {
        w.phase = 'playing'
        w.phaseTime = 0
        lastCount.current = -1
        if (!w.demo) sfx.whistle()
      }
    } else if (w.phase === 'playing') {
      if (!w.demo) {
        if (!w.overtime) {
          w.clock -= dt
          if (w.clock <= 0) {
            w.clock = 0
            if (w.score[0] !== w.score[1]) {
              w.phase = 'ended'
              w.phaseTime = 0
              sfx.whistle()
            } else {
              w.overtime = true
              overtimeAt.current = w.time
              sfx.whistle()
            }
          }
        } else w.clock += dt
      }
    } else if (w.phase === 'goal') {
      if (w.phaseTime > (w.demo ? 2.6 : 3.8)) {
        if (!w.demo && w.overtime) {
          w.phase = 'ended'
          w.phaseTime = 0
        } else resetKickoff(w)
      }
    }

    if (w.phase === 'ended' && !w.demo && !endedSent.current) {
      endedSent.current = true
      store.setScreen('ended')
    }
    if (w.phase !== 'ended') endedSent.current = false

    const timeScale = w.phase === 'goal' && w.phaseTime < 1.3 ? 0.3 : 1
    acc.current += dt * timeScale
    let steps = 0
    while (acc.current >= SIM_DT && steps < 10) {
      for (const r of w.robots) if (r.id !== w.controlled) aiThink(w, r, SIM_DT)
      simStep(w, SIM_DT)
      acc.current -= SIM_DT
      steps++
    }
    if (steps >= 10) acc.current = 0

    for (const e of w.events) {
      const team = e.team ?? 0
      switch (e.type) {
        case 'kick':
          sfx.kick(e.power)
          if ((e.power ?? 0) > 0.6) fxBus.emit?.(e.pos, 18, TEAMS[team].glow, 9, 0.5)
          if (human && e.team === 0 && (e.power ?? 0) > 0.7) vibrate(20)
          break
        case 'bounce':
          sfx.bounce(e.power)
          break
        case 'post':
          sfx.post()
          fxBus.emit?.(e.pos, 24, '#ffffff', 10, 0.6)
          vibrate(40)
          break
        case 'tackle':
          sfx.tackle()
          break
        case 'catch':
          sfx.catch()
          break
        case 'pad':
          sfx.pad()
          break
        case 'demo':
          sfx.demo()
          fxBus.emit?.(e.pos.clone().setY(e.pos.y + 1.6), 60, '#ffd27a', 16, 0.9)
          fxBus.emit?.(e.pos.clone().setY(e.pos.y + 1.6), 30, TEAMS[team].glow, 12, 1.1)
          vibrate(60)
          break
        case 'goal':
          sfx.goal()
          fxBus.emit?.(e.pos.clone().setY(3.5), 220, TEAMS[team].glow, 28, 2.2)
          fxBus.emit?.(e.pos.clone().setY(3.5), 120, '#ffffff', 22, 1.6)
          fxBus.shock?.(e.pos, TEAMS[team].glow)
          vibrate(250)
          break
        case 'whistle':
          sfx.whistle()
          break
      }
    }
    w.events.length = 0

    hudTimer.current -= dt
    if (hudTimer.current <= 0 && !w.demo) {
      hudTimer.current = 0.08
      let message = ''
      let sub = ''
      let messageTeam = -1
      if (w.phase === 'kickoff') {
        message = String(Math.max(1, Math.ceil(kickoffLen - w.phaseTime)))
        sub = w.overtime ? 'GOLDEN GOAL' : 'KICK OFF'
      } else if (w.phase === 'playing' && w.phaseTime < 0.8) {
        message = 'GO!'
      } else if (w.phase === 'goal') {
        message = 'GOAL!'
        sub = w.lastScorer?.name ?? ''
        messageTeam = w.lastScorer?.team ?? -1
      } else if (w.time - overtimeAt.current < 2.5) {
        message = 'OVERTIME'
        sub = 'NEXT GOAL WINS'
      }
      const c = human
      store.setHud({
        score: [w.score[0], w.score[1]],
        clock: w.clock,
        overtime: w.overtime,
        boost: c ? c.boost : 0,
        charge: charge.current,
        controlledName: c ? c.name : '',
        controlledNumber: c ? c.number : 0,
        hasBall: c ? w.possessor === c.id : false,
        message,
        sub,
        messageTeam,
      })
    }
  })

  return null
}

'use client'

import { useRef, useState } from 'react'
import { input, type InputKey } from '@/lib/game/input'
import { useGame } from '@/lib/game/store'
import { cn } from '@/lib/utils'

const RADIUS = 60

function Joystick() {
  const base = useRef<HTMLDivElement>(null)
  const knob = useRef<HTMLDivElement>(null)
  const pointer = useRef<number | null>(null)
  const idle = useRef<HTMLDivElement>(null)
  const origin = useRef({ x: 0, y: 0 })

  const place = (x: number, y: number, kx: number, ky: number) => {
    if (!base.current || !knob.current) return
    base.current.style.transform = `translate(${x - 64}px, ${y - 64}px)`
    base.current.style.opacity = '1'
    knob.current.style.transform = `translate(${kx}px, ${ky}px)`
    if (idle.current) idle.current.style.opacity = '0'
  }

  const reset = () => {
    pointer.current = null
    input.moveX = 0
    input.moveY = 0
    if (base.current) base.current.style.opacity = '0'
    if (knob.current) knob.current.style.transform = ''
    if (idle.current) idle.current.style.opacity = '1'
  }

  return (
    <div
      className="absolute inset-y-0 left-0 w-1/2 touch-none select-none"
      onPointerDown={(e) => {
        if (pointer.current !== null) return
        e.currentTarget.setPointerCapture(e.pointerId)
        pointer.current = e.pointerId
        const rect = e.currentTarget.getBoundingClientRect()
        origin.current = { x: e.clientX - rect.left, y: e.clientY - rect.top }
        place(origin.current.x, origin.current.y, 0, 0)
      }}
      onPointerMove={(e) => {
        if (pointer.current !== e.pointerId) return
        const rect = e.currentTarget.getBoundingClientRect()
        let dx = e.clientX - rect.left - origin.current.x
        let dy = e.clientY - rect.top - origin.current.y
        const d = Math.hypot(dx, dy)
        if (d > RADIUS) {
          dx = (dx / d) * RADIUS
          dy = (dy / d) * RADIUS
        }
        const nx = dx / RADIUS
        const ny = dy / RADIUS
        const mag = Math.hypot(nx, ny)
        input.moveX = mag < 0.12 ? 0 : nx
        input.moveY = mag < 0.12 ? 0 : -ny
        place(origin.current.x, origin.current.y, dx, dy)
      }}
      onPointerUp={reset}
      onPointerCancel={reset}
      onLostPointerCapture={reset}
    >
      <div
        ref={idle}
        aria-hidden
        className="pointer-events-none absolute bottom-8 left-10 flex size-32 items-center justify-center rounded-full border-2 border-dashed border-white/20 bg-white/5"
      >
        <div className="size-14 rounded-full border-2 border-white/25 bg-white/10" />
        <span className="absolute -bottom-5 font-display text-[10px] tracking-[0.3em] text-white/40">MOVE</span>
      </div>
      <div
        ref={base}
        aria-hidden
        className="pointer-events-none absolute left-0 top-0 size-32 rounded-full border-2 border-white/30 bg-white/5 opacity-0 shadow-[0_0_30px_rgba(76,201,255,0.3)]"
      >
        <div
          ref={knob}
          className="absolute left-1/2 top-1/2 -ml-8 -mt-8 size-16 rounded-full border-2 border-cyan-300/80 bg-cyan-400/30 shadow-[0_0_20px_rgba(76,201,255,0.6)]"
        />
      </div>
    </div>
  )
}

function ActionButton({
  k,
  label,
  className,
  size,
  tone = 'default',
  ring,
}: {
  k: InputKey
  label: string
  className: string
  size: number
  tone?: 'shoot' | 'boost' | 'default' | 'accent'
  ring?: number
}) {
  const [down, setDown] = useState(false)
  const release = () => {
    input[k] = false
    setDown(false)
  }
  const tones = {
    shoot: 'border-orange-300/80 bg-gradient-to-b from-orange-400/70 to-orange-600/70 shadow-[0_0_28px_rgba(255,120,40,0.55)]',
    boost: 'border-yellow-200/80 bg-gradient-to-b from-yellow-300/60 to-amber-500/60 shadow-[0_0_22px_rgba(255,210,58,0.45)]',
    accent: 'border-cyan-200/80 bg-gradient-to-b from-cyan-400/50 to-blue-600/60 shadow-[0_0_22px_rgba(76,201,255,0.45)]',
    default: 'border-white/40 bg-white/10 shadow-[0_0_16px_rgba(255,255,255,0.15)]',
  }
  return (
    <button
      type="button"
      aria-label={label}
      className={cn(
        'absolute flex touch-none select-none items-center justify-center rounded-full border-2 font-display text-[11px] font-bold tracking-wider text-white backdrop-blur-sm transition-transform',
        tones[tone],
        down && 'scale-90 brightness-125',
        className,
      )}
      style={{ width: size, height: size }}
      onPointerDown={(e) => {
        e.preventDefault()
        e.stopPropagation()
        e.currentTarget.setPointerCapture(e.pointerId)
        input[k] = true
        setDown(true)
      }}
      onPointerUp={release}
      onPointerCancel={release}
      onLostPointerCapture={release}
      onContextMenu={(e) => e.preventDefault()}
    >
      {ring !== undefined && ring > 0 && (
        <svg className="pointer-events-none absolute -inset-1.5 -rotate-90" viewBox="0 0 100 100" aria-hidden>
          <circle cx="50" cy="50" r="47" fill="none" stroke="#ffd23a" strokeWidth="5" strokeDasharray={`${ring * 295} 295`} strokeLinecap="round" />
        </svg>
      )}
      {label}
    </button>
  )
}

export function TouchControls() {
  const hasBall = useGame((s) => s.hud.hasBall)
  const charge = useGame((s) => s.hud.charge)
  return (
    <div className="absolute inset-0 z-10">
      <Joystick />
      <div className="absolute bottom-0 right-0 h-60 w-72">
        <ActionButton k="shoot" label="SHOOT" tone="shoot" size={92} className="bottom-6 right-5 text-sm" ring={charge} />
        <ActionButton k="pass" label="PASS" tone="accent" size={66} className="bottom-4 right-[124px]" />
        <ActionButton k="lob" label="LOB" size={56} className="bottom-[98px] right-[120px]" />
        <ActionButton k="tackle" label={hasBall ? 'SKILL' : 'TACKLE'} size={62} className="bottom-[128px] right-7 text-[10px]" />
        <ActionButton k="jump" label="JUMP" size={60} className="bottom-[58px] right-[202px]" />
        <ActionButton k="boost" label="BOOST" tone="boost" size={58} className="bottom-[148px] right-[192px]" />
      </div>
    </div>
  )
}

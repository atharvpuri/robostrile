'use client'

import { Trail } from '@react-three/drei'
import { useFrame } from '@react-three/fiber'
import { useMemo, useRef } from 'react'
import * as THREE from 'three'
import { BALL_R, TEAMS } from '@/lib/game/constants'
import { world } from '@/lib/game/world'

const up = new THREE.Vector3(0, 1, 0)
const axis = new THREE.Vector3()
const q = new THREE.Quaternion()
const neutral = new THREE.Color('#e8f4ff')
const teamColors = TEAMS.map((t) => new THREE.Color(t.glow))

export function Ball({ shadows }: { shadows: boolean }) {
  const group = useRef<THREE.Group>(null)
  const spin = useRef<THREE.Group>(null)
  const marker = useRef<THREE.Mesh>(null)
  const markerMat = useRef<THREE.MeshBasicMaterial>(null)
  const glowMat = useRef<THREE.MeshStandardMaterial>(null)
  const light = useRef<THREE.PointLight>(null)

  const panels = useMemo(() => {
    const ico = new THREE.IcosahedronGeometry(1, 0)
    const pos = ico.getAttribute('position')
    const seen: THREE.Vector3[] = []
    for (let i = 0; i < pos.count; i++) {
      const v = new THREE.Vector3().fromBufferAttribute(pos, i).normalize()
      if (!seen.some((s) => s.distanceTo(v) < 0.01)) seen.push(v)
    }
    return seen.map((n) => {
      const quat = new THREE.Quaternion().setFromUnitVectors(up, n)
      return { pos: n.clone().multiplyScalar(BALL_R * 0.975), quat }
    })
  }, [])

  useFrame((_, delta) => {
    const b = world.ball
    if (!group.current || !spin.current) return
    group.current.position.copy(b.pos)
    const speed = Math.hypot(b.vel.x, b.vel.z)
    if (speed > 0.05) {
      axis.set(b.vel.z, 0, -b.vel.x).normalize()
      q.setFromAxisAngle(axis, (speed * Math.min(delta, 0.05)) / BALL_R)
      spin.current.quaternion.premultiply(q)
    }
    if (marker.current && markerMat.current) {
      marker.current.position.set(b.pos.x, 0.05, b.pos.z)
      const h = Math.max(0, b.pos.y - BALL_R)
      const s = 1 + h * 0.06
      marker.current.scale.set(s, 1, s)
      markerMat.current.opacity = Math.max(0.15, 0.7 - h * 0.03)
    }
    const target = b.lastTouchTeam >= 0 ? teamColors[b.lastTouchTeam] : neutral
    if (glowMat.current) {
      glowMat.current.emissive.lerp(target, 0.1)
      glowMat.current.color.copy(glowMat.current.emissive)
      glowMat.current.emissiveIntensity = 2 + Math.min(3, Math.hypot(speed, b.vel.y) / 10)
    }
    if (light.current) light.current.color.lerp(target, 0.1)
  })

  const markerGeo = useMemo(() => {
    const g = new THREE.RingGeometry(BALL_R * 0.7, BALL_R * 1.05, 40)
    g.rotateX(-Math.PI / 2)
    return g
  }, [])

  return (
    <>
      <group ref={group}>
        <Trail width={2.2} length={7} color="#bfe9ff" attenuation={(t) => t * t * t} decay={1.2}>
          <group ref={spin}>
            <mesh castShadow={shadows}>
              <sphereGeometry args={[BALL_R, 40, 28]} />
              <meshStandardMaterial color="#f4f7fb" metalness={0.35} roughness={0.22} />
            </mesh>
            {panels.map((p, i) => (
              <mesh key={i} position={p.pos} quaternion={p.quat}>
                <cylinderGeometry args={[BALL_R * 0.36, BALL_R * 0.36, 0.08, 5]} />
                <meshStandardMaterial color="#121826" metalness={0.6} roughness={0.35} />
              </mesh>
            ))}
            <mesh rotation={[Math.PI / 2, 0, 0]}>
              <torusGeometry args={[BALL_R * 1.005, 0.045, 8, 48]} />
              <meshStandardMaterial ref={glowMat} color="#e8f4ff" emissive="#e8f4ff" emissiveIntensity={2} toneMapped={false} />
            </mesh>
          </group>
        </Trail>
        <pointLight ref={light} distance={9} intensity={18} color="#e8f4ff" decay={2} />
      </group>
      <mesh ref={marker} geometry={markerGeo} renderOrder={2}>
        <meshBasicMaterial ref={markerMat} color="#ffffff" transparent opacity={0.6} depthWrite={false} toneMapped={false} />
      </mesh>
    </>
  )
}

export function BoostPads() {
  const refs = useRef<(THREE.Group | null)[]>([])
  const cyan = TEAMS[0].glow

  useFrame((state) => {
    const t = state.clock.elapsedTime
    world.pads.forEach((p, i) => {
      const g = refs.current[i]
      if (!g) return
      const orb = g.children[2] as THREE.Object3D | undefined
      const target = p.active ? 1 : 0.001
      if (orb) {
        const s = THREE.MathUtils.lerp(orb.scale.x, target, 0.15)
        orb.scale.setScalar(s)
        orb.position.y = (p.big ? 1.6 : 0.5) + Math.sin(t * 3 + i) * 0.2
        orb.rotation.y = t * 1.5
      }
    })
  })

  return (
    <group>
      {world.pads.map((p, i) => (
        <group key={i} ref={(el) => void (refs.current[i] = el)} position={[p.pos.x, 0, p.pos.z]}>
          <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.03, 0]} receiveShadow>
            <circleGeometry args={[p.big ? 2.2 : 1.4, 32]} />
            <meshStandardMaterial color="#0d1424" metalness={0.8} roughness={0.3} />
          </mesh>
          <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.05, 0]}>
            <ringGeometry args={[p.big ? 1.8 : 1.1, p.big ? 2.2 : 1.4, 40]} />
            <meshBasicMaterial color="#ffd23a" toneMapped={false} />
          </mesh>
          <mesh>
            {p.big ? <octahedronGeometry args={[0.8, 0]} /> : <cylinderGeometry args={[0.7, 0.7, 0.12, 20]} />}
            <meshStandardMaterial color="#ffd23a" emissive="#ffb000" emissiveIntensity={2.5} toneMapped={false} />
          </mesh>
          <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0.04, 0]}>
            <circleGeometry args={[p.big ? 1.2 : 0.7, 24]} />
            <meshBasicMaterial color={cyan} transparent opacity={0.2} toneMapped={false} />
          </mesh>
        </group>
      ))}
    </group>
  )
}

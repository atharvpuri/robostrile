'use client'

import { Environment, Lightformer, Stars } from '@react-three/drei'
import { Canvas } from '@react-three/fiber'
import { Bloom, EffectComposer, Vignette } from '@react-three/postprocessing'
import { Suspense } from 'react'
import * as THREE from 'three'
import { HALF_L } from '@/lib/game/constants'
import { useGame } from '@/lib/game/store'
import { world } from '@/lib/game/world'
import { Ball, BoostPads } from './ball'
import { CameraRig } from './camera-rig'
import { Effects } from './effects'
import { GameLoop } from './game-loop'
import { Robot } from './robot'
import { Stadium } from './stadium'

function Lights({ shadows }: { shadows: boolean }) {
  return (
    <>
      <hemisphereLight args={['#a8c8ff', '#0b1020', 0.55]} />
      <ambientLight intensity={0.15} />
      <directionalLight
        position={[30, 70, -25]}
        intensity={2.4}
        color="#fff6e8"
        castShadow={shadows}
        shadow-mapSize={[2048, 2048]}
        shadow-camera-left={-45}
        shadow-camera-right={45}
        shadow-camera-top={65}
        shadow-camera-bottom={-65}
        shadow-camera-near={10}
        shadow-camera-far={180}
        shadow-bias={-0.0004}
        shadow-normalBias={0.04}
      />
      <directionalLight position={[-40, 50, 40]} intensity={0.9} color="#bcd7ff" />
    </>
  )
}

export default function Scene() {
  const quality = useGame((s) => s.quality)
  const high = quality === 'high'

  return (
    <Canvas
      shadows={high}
      dpr={high ? [1, 1.75] : [0.75, 1]}
      camera={{ fov: 56, position: [0, 30, -80], near: 0.5, far: 700 }}
      gl={{ antialias: !high, powerPreference: 'high-performance', toneMapping: THREE.ACESFilmicToneMapping }}
      className="touch-none"
    >
      <color attach="background" args={['#040814']} />
      <fog attach="fog" args={['#040814', 140, 360]} />
      <GameLoop />
      <CameraRig />
      <Lights shadows={high} />
      <Suspense fallback={null}>
        <Stadium quality={quality} />
        <BoostPads />
        <Ball shadows={high} />
        {world.robots.map((r) => (
          <Robot key={r.id} index={r.id} shadows={high} />
        ))}
        <Effects />
        <Stars radius={260} depth={60} count={high ? 2500 : 900} factor={6} saturation={0} fade speed={0.6} />
        <Environment resolution={128} frames={1}>
          <Lightformer intensity={3} position={[0, 30, 0]} rotation={[Math.PI / 2, 0, 0]} scale={[60, 60, 1]} />
          <Lightformer intensity={2} color="#4cc9ff" position={[0, 8, -HALF_L - 10]} scale={[40, 10, 1]} />
          <Lightformer intensity={2} color="#ffa23a" position={[0, 8, HALF_L + 10]} rotation={[0, Math.PI, 0]} scale={[40, 10, 1]} />
          <Lightformer intensity={1.5} position={[-50, 15, 0]} rotation={[0, Math.PI / 2, 0]} scale={[80, 8, 1]} />
          <Lightformer intensity={1.5} position={[50, 15, 0]} rotation={[0, -Math.PI / 2, 0]} scale={[80, 8, 1]} />
        </Environment>
      </Suspense>
      {high && (
        <EffectComposer multisampling={4}>
          <Bloom intensity={0.85} luminanceThreshold={0.9} luminanceSmoothing={0.2} mipmapBlur />
          <Vignette offset={0.3} darkness={0.55} />
        </EffectComposer>
      )}
    </Canvas>
  )
}

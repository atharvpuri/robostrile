'use client'

import { useFrame } from '@react-three/fiber'
import { useEffect, useMemo, useRef } from 'react'
import * as THREE from 'three'
import { fxBus } from '@/lib/game/fx-bus'

const MAX = 600
const dummy = new THREE.Object3D()
const tmpColor = new THREE.Color()

export function Effects() {
  const mesh = useRef<THREE.InstancedMesh>(null)
  const shockRefs = useRef<(THREE.Mesh | null)[]>([])
  const data = useMemo(
    () => ({
      pos: new Float32Array(MAX * 3),
      vel: new Float32Array(MAX * 3),
      life: new Float32Array(MAX),
      max: new Float32Array(MAX),
      size: new Float32Array(MAX),
      cursor: 0,
      shocks: [0, 1, 2].map(() => ({ t: 10 })),
      shockCursor: 0,
    }),
    [],
  )

  useEffect(() => {
    const m = mesh.current
    if (!m) return
    dummy.scale.setScalar(0)
    dummy.updateMatrix()
    for (let i = 0; i < MAX; i++) {
      m.setMatrixAt(i, dummy.matrix)
      m.setColorAt(i, tmpColor.set('#ffffff'))
    }
    m.instanceMatrix.needsUpdate = true
    if (m.instanceColor) m.instanceColor.needsUpdate = true

    fxBus.emit = (p, count, color, speed, life = 1) => {
      tmpColor.set(color)
      for (let n = 0; n < count; n++) {
        const i = data.cursor
        data.cursor = (data.cursor + 1) % MAX
        data.pos[i * 3] = p.x
        data.pos[i * 3 + 1] = p.y
        data.pos[i * 3 + 2] = p.z
        const u = Math.random() * 2 - 1
        const th = Math.random() * Math.PI * 2
        const r = Math.sqrt(1 - u * u)
        const sp = speed * (0.3 + Math.random() * 0.7)
        data.vel[i * 3] = r * Math.cos(th) * sp
        data.vel[i * 3 + 1] = Math.abs(u) * sp * 0.9 + speed * 0.2
        data.vel[i * 3 + 2] = r * Math.sin(th) * sp
        data.max[i] = data.life[i] = life * (0.5 + Math.random() * 0.5)
        data.size[i] = 0.12 + Math.random() * 0.22
        m.setColorAt(i, tmpColor)
      }
      if (m.instanceColor) m.instanceColor.needsUpdate = true
    }
    fxBus.shock = (p, color) => {
      const idx = data.shockCursor
      data.shockCursor = (idx + 1) % 3
      data.shocks[idx].t = 0
      const s = shockRefs.current[idx]
      if (s) {
        s.position.set(p.x, 0.2, p.z)
        ;(s.material as THREE.MeshBasicMaterial).color.set(color)
      }
    }
    return () => {
      fxBus.emit = null
      fxBus.shock = null
    }
  }, [data])

  useFrame((_, delta) => {
    const m = mesh.current
    if (!m) return
    const dt = Math.min(delta, 0.05)
    let dirty = false
    for (let i = 0; i < MAX; i++) {
      if (data.life[i] <= 0) continue
      dirty = true
      data.life[i] -= dt
      const k = i * 3
      data.vel[k + 1] -= 18 * dt
      data.vel[k] *= 1 - 0.8 * dt
      data.vel[k + 2] *= 1 - 0.8 * dt
      data.pos[k] += data.vel[k] * dt
      data.pos[k + 1] += data.vel[k + 1] * dt
      data.pos[k + 2] += data.vel[k + 2] * dt
      if (data.pos[k + 1] < 0.1) {
        data.pos[k + 1] = 0.1
        data.vel[k + 1] *= -0.4
      }
      const f = Math.max(0, data.life[i] / data.max[i])
      dummy.position.set(data.pos[k], data.pos[k + 1], data.pos[k + 2])
      dummy.scale.setScalar(data.size[i] * (0.3 + f))
      dummy.rotation.set(data.pos[k], data.pos[k + 2], 0)
      dummy.updateMatrix()
      m.setMatrixAt(i, dummy.matrix)
    }
    if (dirty) m.instanceMatrix.needsUpdate = true

    data.shocks.forEach((s, i) => {
      const mesh = shockRefs.current[i]
      if (!mesh) return
      s.t += dt
      const visible = s.t < 1.2
      mesh.visible = visible
      if (visible) {
        const sc = 1 + s.t * 30
        mesh.scale.set(sc, sc, sc)
        ;(mesh.material as THREE.MeshBasicMaterial).opacity = Math.max(0, 0.8 * (1 - s.t / 1.2))
      }
    })
  })

  return (
    <>
      <instancedMesh ref={mesh} args={[undefined, undefined, MAX]} frustumCulled={false}>
        <icosahedronGeometry args={[1, 0]} />
        <meshBasicMaterial toneMapped={false} />
      </instancedMesh>
      {[0, 1, 2].map((i) => (
        <mesh key={i} ref={(el) => void (shockRefs.current[i] = el)} rotation={[-Math.PI / 2, 0, 0]} visible={false}>
          <ringGeometry args={[0.85, 1, 64]} />
          <meshBasicMaterial transparent opacity={0} toneMapped={false} depthWrite={false} side={THREE.DoubleSide} />
        </mesh>
      ))}
    </>
  )
}

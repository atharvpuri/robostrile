'use client'

import { Maximize, Play, RotateCcw, Smartphone, Volume2, VolumeX, Home } from 'lucide-react'
import { ensureAudio, setSoundEnabled } from '@/lib/game/audio'
import { TEAMS, type Difficulty } from '@/lib/game/constants'
import { useGame } from '@/lib/game/store'
import { startMatch, world } from '@/lib/game/world'
import { cn } from '@/lib/utils'

function Segmented<T extends string | number>({
  label,
  value,
  options,
  onChange,
}: {
  label: string
  value: T
  options: { value: T; label: string }[]
  onChange: (v: T) => void
}) {
  return (
    <fieldset className="flex flex-col gap-1.5">
      <legend className="mb-1.5 font-display text-[10px] font-bold tracking-[0.3em] text-white/50">{label}</legend>
      <div className="grid grid-flow-col gap-1 rounded-xl border border-white/10 bg-black/30 p-1">
        {options.map((o) => (
          <button
            key={String(o.value)}
            type="button"
            aria-pressed={value === o.value}
            onClick={() => onChange(o.value)}
            className={cn(
              'rounded-lg px-3 py-2 font-display text-xs font-bold tracking-wider transition-colors',
              value === o.value ? 'bg-[#4cc9ff] text-[#040814] shadow-[0_0_18px_rgba(76,201,255,0.5)]' : 'text-white/70 hover:bg-white/10',
            )}
          >
            {o.label}
          </button>
        ))}
      </div>
    </fieldset>
  )
}

function goFullscreen() {
  const coarse = window.matchMedia('(pointer: coarse)').matches
  if (!coarse || document.fullscreenElement) return
  const el = document.documentElement
  el.requestFullscreen?.()
    .then(() => {
      const o = screen.orientation as ScreenOrientation & { lock?: (o: string) => Promise<void> }
      return o.lock?.('landscape')
    })
    .catch(() => {})
}

export function launchMatch() {
  const s = useGame.getState()
  ensureAudio()
  setSoundEnabled(s.sound)
  startMatch(world, { demo: false, difficulty: s.difficulty, minutes: s.minutes })
  s.setHud({ score: [0, 0], clock: s.minutes * 60, overtime: false, message: '', sub: '', charge: 0 })
  s.startMatch()
}

export function quitToMenu() {
  startMatch(world, { demo: true, difficulty: 'pro', minutes: 3 })
  useGame.getState().setScreen('menu')
}

export function MainMenu() {
  const { difficulty, minutes, quality, sound, setDifficulty, setMinutes, setQuality, setSound } = useGame()
  return (
    <div className="absolute inset-0 z-40 flex overflow-y-auto bg-gradient-to-r from-[#040814]/95 via-[#040814]/70 to-transparent">
      <div className="flex w-full max-w-xl flex-col justify-center gap-6 p-6 sm:p-10">
        <header>
          <p className="font-display text-[10px] font-bold tracking-[0.5em] text-[#4cc9ff]">3V3 ROCKET ROBOT FOOTBALL</p>
          <h1 className="mt-2 font-display text-5xl font-black italic leading-[0.9] text-white sm:text-7xl">
            ROBO<span className="text-[#ffa23a]">STRIKE</span>
            <span className="block text-3xl tracking-[0.2em] text-white/90 sm:text-4xl">ARENA</span>
          </h1>
          <p className="mt-3 max-w-md text-sm leading-relaxed text-white/70">
            Jet-powered robots with real football skills. Dribble, chip, volley and slide-tackle your way to glory in a
            neon-lit stadium.
          </p>
        </header>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 rounded-xl border border-[#4cc9ff]/30 bg-[#1d8bff]/15 px-3 py-2">
            <span className="size-3 rounded-full bg-[#4cc9ff] shadow-[0_0_10px_#4cc9ff]" />
            <span className="font-display text-xs font-bold tracking-widest text-white">{TEAMS[0].name}</span>
            <span className="text-[10px] text-white/50">YOU</span>
          </div>
          <span className="font-display text-xs font-bold text-white/40">VS</span>
          <div className="flex items-center gap-2 rounded-xl border border-[#ffa23a]/30 bg-[#ff5a1f]/15 px-3 py-2">
            <span className="size-3 rounded-full bg-[#ffa23a] shadow-[0_0_10px_#ffa23a]" />
            <span className="font-display text-xs font-bold tracking-widest text-white">{TEAMS[1].name}</span>
            <span className="text-[10px] text-white/50">CPU</span>
          </div>
        </div>

        <div className="grid gap-4 rounded-2xl border border-white/10 bg-white/[0.03] p-4 backdrop-blur-md sm:grid-cols-2">
          <Segmented<Difficulty>
            label="DIFFICULTY"
            value={difficulty}
            onChange={setDifficulty}
            options={[
              { value: 'rookie', label: 'ROOKIE' },
              { value: 'pro', label: 'PRO' },
              { value: 'legend', label: 'LEGEND' },
            ]}
          />
          <Segmented<number>
            label="MATCH LENGTH"
            value={minutes}
            onChange={setMinutes}
            options={[
              { value: 2, label: '2 MIN' },
              { value: 3, label: '3 MIN' },
              { value: 5, label: '5 MIN' },
            ]}
          />
          <Segmented<'high' | 'performance'>
            label="GRAPHICS"
            value={quality}
            onChange={setQuality}
            options={[
              { value: 'high', label: 'ULTRA' },
              { value: 'performance', label: 'FAST' },
            ]}
          />
          <fieldset className="flex flex-col">
            <legend className="mb-1.5 font-display text-[10px] font-bold tracking-[0.3em] text-white/50">AUDIO</legend>
            <button
              type="button"
              aria-pressed={sound}
              onClick={() => {
                setSound(!sound)
                setSoundEnabled(!sound)
              }}
              className="flex items-center justify-center gap-2 rounded-xl border border-white/10 bg-black/30 px-3 py-3 font-display text-xs font-bold tracking-wider text-white"
            >
              {sound ? <Volume2 className="size-4 text-[#4cc9ff]" aria-hidden /> : <VolumeX className="size-4" aria-hidden />}
              {sound ? 'SOUND ON' : 'MUTED'}
            </button>
          </fieldset>
        </div>

        <div className="flex flex-wrap gap-3">
          <button
            type="button"
            onClick={() => {
              goFullscreen()
              launchMatch()
            }}
            className="group flex items-center gap-3 rounded-2xl bg-gradient-to-r from-[#ffa23a] to-[#ff5a1f] px-8 py-4 font-display text-lg font-black italic tracking-wider text-[#040814] shadow-[0_0_40px_rgba(255,120,40,0.5)] transition-transform hover:scale-[1.03] active:scale-95"
          >
            <Play className="size-5 fill-current" aria-hidden />
            KICK OFF
          </button>
          <button
            type="button"
            onClick={goFullscreen}
            className="flex items-center gap-2 rounded-2xl border border-white/15 bg-white/5 px-5 py-4 font-display text-xs font-bold tracking-wider text-white backdrop-blur pointer-fine:hidden"
          >
            <Maximize className="size-4" aria-hidden />
            FULLSCREEN
          </button>
        </div>

        <details className="rounded-2xl border border-white/10 bg-black/30 p-4 text-sm text-white/70 backdrop-blur-md">
          <summary className="cursor-pointer font-display text-xs font-bold tracking-[0.25em] text-white">HOW TO PLAY</summary>
          <ul className="mt-3 grid gap-1.5 sm:grid-cols-2">
            <li><b className="text-white">Joystick / WASD</b> — run & dribble</li>
            <li><b className="text-white">Shoot / J</b> — hold to power up, release</li>
            <li><b className="text-white">Pass / K</b> — ground pass to teammate</li>
            <li><b className="text-white">Lob / L</b> — chipped through-ball</li>
            <li><b className="text-white">Tackle / I</b> — slide tackle (skill move on ball)</li>
            <li><b className="text-white">Jump / Space</b> — hold in air for rocket flight</li>
            <li><b className="text-white">Boost / Shift</b> — sprint; ram rivals to demolish</li>
            <li><b className="text-white">Switch / Q</b> — control nearest teammate</li>
          </ul>
          <p className="mt-3 text-xs text-white/50">Collect glowing yellow pads to refill boost. Headers and volleys happen when you shoot an airborne ball.</p>
        </details>

        <p className="flex items-center gap-2 text-xs text-white/50 pointer-fine:hidden portrait:flex landscape:hidden">
          <Smartphone className="size-4 rotate-90" aria-hidden />
          Rotate your phone to landscape for the best experience.
        </p>
      </div>
    </div>
  )
}

export function PauseMenu() {
  const setScreen = useGame((s) => s.setScreen)
  return (
    <div className="absolute inset-0 z-40 flex items-center justify-center bg-[#040814]/75 p-6 backdrop-blur-md">
      <div className="flex w-full max-w-xs flex-col gap-3 rounded-2xl border border-white/10 bg-[#0a1124]/90 p-6 text-center">
        <h2 className="font-display text-3xl font-black italic text-white">PAUSED</h2>
        <button
          type="button"
          onClick={() => setScreen('playing')}
          className="flex items-center justify-center gap-2 rounded-xl bg-[#4cc9ff] py-3 font-display text-sm font-bold tracking-wider text-[#040814]"
        >
          <Play className="size-4 fill-current" aria-hidden /> RESUME
        </button>
        <button
          type="button"
          onClick={launchMatch}
          className="flex items-center justify-center gap-2 rounded-xl border border-white/15 py-3 font-display text-sm font-bold tracking-wider text-white"
        >
          <RotateCcw className="size-4" aria-hidden /> RESTART
        </button>
        <button
          type="button"
          onClick={quitToMenu}
          className="flex items-center justify-center gap-2 rounded-xl border border-white/15 py-3 font-display text-sm font-bold tracking-wider text-white"
        >
          <Home className="size-4" aria-hidden /> MAIN MENU
        </button>
      </div>
    </div>
  )
}

export function EndScreen() {
  const score = useGame((s) => s.hud.score)
  const win = score[0] > score[1]
  const color = win ? TEAMS[0].glow : TEAMS[1].glow
  return (
    <div className="absolute inset-0 z-40 flex items-center justify-center bg-[#040814]/70 p-6 backdrop-blur-sm">
      <div className="flex w-full max-w-md flex-col items-center gap-5 rounded-3xl border border-white/10 bg-[#0a1124]/90 p-8 text-center shadow-2xl">
        <p className="font-display text-[10px] font-bold tracking-[0.5em] text-white/50">FULL TIME</p>
        <h2
          className="font-display text-6xl font-black italic"
          style={{ color, textShadow: `0 0 30px ${color}` }}
        >
          {win ? 'VICTORY' : 'DEFEAT'}
        </h2>
        <div className="flex items-center gap-6 font-display">
          <div className="flex flex-col items-center">
            <span className="text-xs tracking-widest text-[#4cc9ff]">{TEAMS[0].name}</span>
            <span className="text-5xl font-black text-white">{score[0]}</span>
          </div>
          <span className="text-2xl text-white/30">—</span>
          <div className="flex flex-col items-center">
            <span className="text-xs tracking-widest text-[#ffa23a]">{TEAMS[1].name}</span>
            <span className="text-5xl font-black text-white">{score[1]}</span>
          </div>
        </div>
        <div className="flex w-full gap-3">
          <button
            type="button"
            onClick={launchMatch}
            className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-gradient-to-r from-[#ffa23a] to-[#ff5a1f] py-3 font-display text-sm font-black tracking-wider text-[#040814]"
          >
            <RotateCcw className="size-4" aria-hidden /> REMATCH
          </button>
          <button
            type="button"
            onClick={quitToMenu}
            className="flex flex-1 items-center justify-center gap-2 rounded-xl border border-white/15 py-3 font-display text-sm font-bold tracking-wider text-white"
          >
            <Home className="size-4" aria-hidden /> MENU
          </button>
        </div>
      </div>
    </div>
  )
}

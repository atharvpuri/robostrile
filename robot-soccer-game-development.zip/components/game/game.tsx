'use client'

import dynamic from 'next/dynamic'
import { useEffect, useSyncExternalStore } from 'react'
import { keys } from '@/lib/game/input'
import { useGame } from '@/lib/game/store'
import { Hud } from './hud'
import { EndScreen, MainMenu, PauseMenu } from './menus'
import { TouchControls } from './touch-controls'

const Scene = dynamic(() => import('./scene'), {
  ssr: false,
  loading: () => (
    <div className="flex size-full items-center justify-center bg-[#040814]">
      <p className="animate-pulse font-display text-sm font-bold tracking-[0.4em] text-[#4cc9ff]">LOADING ARENA…</p>
    </div>
  ),
})

const coarseQuery = '(pointer: coarse)'
function subscribeCoarse(cb: () => void) {
  const mq = window.matchMedia(coarseQuery)
  mq.addEventListener('change', cb)
  return () => mq.removeEventListener('change', cb)
}

export function Game() {
  const screen = useGame((s) => s.screen)
  const touch = useSyncExternalStore(
    subscribeCoarse,
    () =>
      window.matchMedia(coarseQuery).matches ||
      navigator.maxTouchPoints > 0 ||
      /Android|iPhone|iPad|Mobile/i.test(navigator.userAgent),
    () => false,
  )

  useEffect(() => {
    const gameKeys = new Set(['Space', 'ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'])
    const down = (e: KeyboardEvent) => {
      if (e.code === 'Escape' || e.code === 'KeyP') {
        const s = useGame.getState()
        if (s.screen === 'playing') s.setScreen('paused')
        else if (s.screen === 'paused') s.setScreen('playing')
        return
      }
      if (gameKeys.has(e.code) && useGame.getState().screen === 'playing') e.preventDefault()
      keys.add(e.code)
    }
    const up = (e: KeyboardEvent) => keys.delete(e.code)
    const blur = () => keys.clear()
    window.addEventListener('keydown', down)
    window.addEventListener('keyup', up)
    window.addEventListener('blur', blur)
    return () => {
      window.removeEventListener('keydown', down)
      window.removeEventListener('keyup', up)
      window.removeEventListener('blur', blur)
    }
  }, [])

  const inMatch = screen === 'playing' || screen === 'paused' || screen === 'ended'

  return (
    <main className="fixed inset-0 select-none overflow-hidden bg-[#040814] text-white touch-none">
      <h1 className="sr-only">RoboStrike Arena — 3v3 rocket robot football</h1>
      <div className="absolute inset-0">
        <Scene />
      </div>
      {inMatch && <Hud touch={touch} />}
      {screen === 'playing' && touch && <TouchControls />}
      {screen === 'menu' && <MainMenu />}
      {screen === 'paused' && <PauseMenu />}
      {screen === 'ended' && <EndScreen />}
    </main>
  )
}

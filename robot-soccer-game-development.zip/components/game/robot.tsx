'use client'

import { useFrame } from '@react-three/fiber'
import { memo, useMemo, useRef } from 'react'
import * as THREE from 'three'
import { RoundedBoxGeometry } from 'three/examples/jsm/geometries/RoundedBoxGeometry.js'
import { TEAMS } from '@/lib/game/constants'
import { world } from '@/lib/game/world'

const damp = THREE.MathUtils.damp

let geoCache: ReturnType<typeof makeGeometries> | null = null
function makeGeometries() {
  const flame = new THREE.ConeGeometry(0.15, 1, 12, 1, true)
  flame.rotateX(Math.PI)
  flame.translate(0, -0.5, 0)
  const flameCore = new THREE.ConeGeometry(0.08, 0.7, 10, 1, true)
  flameCore.rotateX(Math.PI)
  flameCore.translate(0, -0.35, 0)
  const ring = new THREE.RingGeometry(1.45, 1.8, 48)
  ring.rotateX(-Math.PI / 2)
  const disc = new THREE.CircleGeometry(1.5, 32)
  disc.rotateX(-Math.PI / 2)
  const arrow = new THREE.ConeGeometry(0.32, 0.6, 4)
  arrow.rotateX(Math.PI)
  return {
    chest: new RoundedBoxGeometry(1.15, 0.95, 0.72, 3, 0.18),
    head: new RoundedBoxGeometry(0.78, 0.62, 0.7, 3, 0.17),
    pack: new RoundedBoxGeometry(0.72, 0.8, 0.34, 2, 0.1),
    pelvis: new RoundedBoxGeometry(0.82, 0.32, 0.52, 2, 0.1),
    foot: new RoundedBoxGeometry(0.36, 0.22, 0.62, 2, 0.08),
    thigh: new THREE.CapsuleGeometry(0.2, 0.42, 4, 10),
    shin: new THREE.CapsuleGeometry(0.18, 0.4, 4, 10),
    upperArm: new THREE.CapsuleGeometry(0.15, 0.34, 4, 10),
    foreArm: new THREE.CapsuleGeometry(0.13, 0.3, 4, 10),
    joint: new THREE.SphereGeometry(1, 16, 12),
    abdomen: new THREE.CylinderGeometry(0.34, 0.3, 0.36, 16),
    neck: new THREE.CylinderGeometry(0.15, 0.18, 0.22, 12),
    nozzle: new THREE.CylinderGeometry(0.11, 0.15, 0.26, 12, 1, true),
    ear: new THREE.CylinderGeometry(0.14, 0.14, 0.1, 16),
    antenna: new THREE.CylinderGeometry(0.025, 0.025, 0.38, 6),
    visor: new RoundedBoxGeometry(0.66, 0.2, 0.08, 2, 0.04),
    core: new THREE.CylinderGeometry(0.17, 0.17, 0.05, 20),
    stripe: new THREE.BoxGeometry(0.92, 0.07, 0.03),
    plate: new THREE.PlaneGeometry(0.62, 0.62),
    flame,
    flameCore,
    ring,
    disc,
    arrow,
  }
}
function geos() {
  if (!geoCache) geoCache = makeGeometries()
  return geoCache
}

function numberTexture(n: number, color: string) {
  const c = document.createElement('canvas')
  c.width = c.height = 128
  const ctx = c.getContext('2d')!
  ctx.clearRect(0, 0, 128, 128)
  ctx.font = 'bold 96px system-ui, sans-serif'
  ctx.textAlign = 'center'
  ctx.textBaseline = 'middle'
  ctx.lineWidth = 8
  ctx.strokeStyle = '#0b0f1a'
  ctx.strokeText(String(n), 64, 70)
  ctx.fillStyle = color
  ctx.fillText(String(n), 64, 70)
  const t = new THREE.CanvasTexture(c)
  t.colorSpace = THREE.SRGBColorSpace
  return t
}

const matCache = new Map<number, ReturnType<typeof makeMaterials>>()
function makeMaterials(team: 0 | 1) {
  const t = TEAMS[team]
  return {
    armor: new THREE.MeshStandardMaterial({ color: t.main, metalness: 0.55, roughness: 0.28 }),
    chrome: new THREE.MeshStandardMaterial({ color: '#dfe5ee', metalness: 0.92, roughness: 0.18 }),
    dark: new THREE.MeshStandardMaterial({ color: '#161b26', metalness: 0.75, roughness: 0.4 }),
    glow: new THREE.MeshStandardMaterial({
      color: t.glow,
      emissive: t.glow,
      emissiveIntensity: 3.2,
      toneMapped: false,
    }),
    flame: new THREE.MeshBasicMaterial({
      color: team === 0 ? '#5fd4ff' : '#ff9a3a',
      transparent: true,
      opacity: 0.75,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      toneMapped: false,
      side: THREE.DoubleSide,
    }),
    flameCore: new THREE.MeshBasicMaterial({
      color: '#ffffff',
      transparent: true,
      opacity: 0.9,
      blending: THREE.AdditiveBlending,
      depthWrite: false,
      toneMapped: false,
    }),
    ring: new THREE.MeshBasicMaterial({
      color: '#ffffff',
      transparent: true,
      opacity: 0.85,
      toneMapped: false,
      depthWrite: false,
    }),
    disc: new THREE.MeshBasicMaterial({
      color: t.glow,
      transparent: true,
      opacity: 0.22,
      toneMapped: false,
      depthWrite: false,
    }),
    arrow: new THREE.MeshBasicMaterial({ color: t.glow, toneMapped: false }),
  }
}
function mats(team: 0 | 1) {
  let m = matCache.get(team)
  if (!m) {
    m = makeMaterials(team)
    matCache.set(team, m)
  }
  return m
}

type Joint = THREE.Group | null

export const Robot = memo(function Robot({ index, shadows }: { index: number; shadows: boolean }) {
  const r = world.robots[index]
  const g = geos()
  const m = mats(r.team)
  const numberMat = useMemo(
    () =>
      new THREE.MeshBasicMaterial({
        map: numberTexture(r.number, '#ffffff'),
        transparent: true,
        toneMapped: false,
      }),
    [r.number],
  )

  const root = useRef<THREE.Group>(null)
  const body = useRef<THREE.Group>(null)
  const torso = useRef<THREE.Group>(null)
  const head = useRef<THREE.Group>(null)
  const legL = useRef<THREE.Group>(null)
  const legR = useRef<THREE.Group>(null)
  const kneeL = useRef<THREE.Group>(null)
  const kneeR = useRef<THREE.Group>(null)
  const armL = useRef<THREE.Group>(null)
  const armR = useRef<THREE.Group>(null)
  const elbowL = useRef<THREE.Group>(null)
  const elbowR = useRef<THREE.Group>(null)
  const flames = useRef<THREE.Group>(null)
  const ground = useRef<THREE.Group>(null)
  const ring = useRef<THREE.Mesh>(null)
  const disc = useRef<THREE.Mesh>(null)
  const arrow = useRef<THREE.Mesh>(null)

  useFrame((state, delta) => {
    const rb = world.robots[index]
    const w = world
    if (!root.current || !body.current) return
    const t = state.clock.elapsedTime
    const d = Math.min(delta, 0.05)
    root.current.position.copy(rb.pos)

    let yaw = rb.facing
    if (rb.state === 'skill') yaw += (1 - rb.stateTime / 0.55) * Math.PI * 2
    root.current.rotation.y = yaw

    const speed = Math.hypot(rb.vel.x, rb.vel.z)
    const run = Math.min(1, speed / 12)
    const ph = rb.animPhase
    const sw = Math.sin(ph)

    let lT = -sw * 0.95 * run
    let rT = sw * 0.95 * run
    let lS = 0.1 + (0.2 + Math.max(0, Math.cos(ph)) * 1.1) * run
    let rS = 0.1 + (0.2 + Math.max(0, -Math.cos(ph)) * 1.1) * run
    let aL = sw * 0.85 * run
    let aR = -sw * 0.85 * run
    let eL = -0.5 - run * 0.5
    let eR = -0.5 - run * 0.5
    let tilt = run * 0.16 + (rb.boosting && rb.onGround ? 0.18 : 0)
    let bodyY = 1.35 + Math.abs(Math.sin(ph)) * 0.12 * run + Math.sin(t * 2 + index) * 0.02
    let wobble = 0
    let headYaw = 0

    if (!rb.onGround) {
      lT = -1.0
      rT = -0.35
      lS = 1.4
      rS = 0.5
      aL = -0.4
      aR = -0.4
      eL = -1.2
      eR = -1.2
      tilt = 0.25
    }
    if (rb.kickAnim > 0) {
      const k = 1 - rb.kickAnim
      rT = k < 0.35 ? (k / 0.35) * 0.9 : 0.9 - ((k - 0.35) / 0.65) * 2.6
      rS = k < 0.35 ? 1.3 : 0.15
      aL = -0.9
      aR = 0.6
      tilt = -0.1
    }
    if (rb.state === 'slide') {
      tilt = -1.05
      bodyY = 0.75
      lT = -1.5
      rT = -0.9
      lS = 0.05
      rS = 0.9
      aL = 0.6
      aR = 0.6
    }
    if (rb.state === 'stun') {
      wobble = Math.sin(t * 18) * 0.4
      aL = -2 + Math.sin(t * 20) * 0.6
      aR = -2 + Math.cos(t * 20) * 0.6
      headYaw = Math.sin(t * 14) * 0.6
    }
    const celebrating = w.phase === 'goal' && w.lastScorer?.team === rb.team && w.phaseTime > 0.6
    if (celebrating) {
      aL = -2.9 + Math.sin(t * 10 + index) * 0.25
      aR = -2.9 + Math.cos(t * 10 + index) * 0.25
      eL = -0.2
      eR = -0.2
      bodyY += Math.abs(Math.sin(t * 7 + index)) * 0.35
    }
    if (w.phase === 'goal' && w.lastScorer && w.lastScorer.team !== rb.team && w.phaseTime > 0.6) {
      tilt = 0.5
      aL = 0.2
      aR = 0.2
    }
    if (w.possessor === index && rb.role === 'keeper' && rb.holdTime > 0) {
      aL = -1.3
      aR = -1.3
      eL = -0.5
      eR = -0.5
    }

    const k = 16
    body.current.position.y = damp(body.current.position.y, bodyY, k, d)
    body.current.rotation.x = damp(body.current.rotation.x, tilt, 10, d)
    body.current.rotation.z = damp(body.current.rotation.z, wobble, 12, d)
    if (legL.current) legL.current.rotation.x = damp(legL.current.rotation.x, lT, k, d)
    if (legR.current) legR.current.rotation.x = damp(legR.current.rotation.x, rT, rb.kickAnim > 0 ? 30 : k, d)
    if (kneeL.current) kneeL.current.rotation.x = damp(kneeL.current.rotation.x, lS, k, d)
    if (kneeR.current) kneeR.current.rotation.x = damp(kneeR.current.rotation.x, rS, k, d)
    if (armL.current) armL.current.rotation.x = damp(armL.current.rotation.x, aL, 12, d)
    if (armR.current) armR.current.rotation.x = damp(armR.current.rotation.x, aR, 12, d)
    if (elbowL.current) elbowL.current.rotation.x = damp(elbowL.current.rotation.x, eL, 12, d)
    if (elbowR.current) elbowR.current.rotation.x = damp(elbowR.current.rotation.x, eR, 12, d)
    if (head.current) {
      let look = 0
      if (rb.state !== 'stun') {
        const dx = w.ball.pos.x - rb.pos.x
        const dz = w.ball.pos.z - rb.pos.z
        const rel = Math.atan2(dx, dz) - yaw
        look = Math.max(-0.9, Math.min(0.9, Math.atan2(Math.sin(rel), Math.cos(rel))))
      }
      head.current.rotation.y = damp(head.current.rotation.y, look + headYaw, 8, d)
    }

    if (flames.current) {
      const th = rb.thrust
      flames.current.visible = th > 0.04
      const flick = 0.8 + Math.random() * 0.4
      const len = (rb.onGround ? 0.8 : 1.6) * th * flick
      flames.current.scale.set(1, Math.max(0.01, len), 1)
    }

    if (ground.current) ground.current.position.y = -rb.pos.y + 0.04
    const isControlled = index === w.controlled
    if (ring.current) {
      ring.current.visible = isControlled
      const s = 1 + Math.sin(t * 6) * 0.06
      ring.current.scale.set(s, 1, s)
    }
    if (disc.current) disc.current.visible = w.possessor === index
    if (arrow.current) {
      arrow.current.visible = isControlled
      arrow.current.position.y = 4.9 + Math.sin(t * 5) * 0.15
      arrow.current.rotation.y = t * 2
    }
  })

  const cast = shadows

  const leg = (side: -1 | 1, legRef: React.RefObject<Joint>, kneeRef: React.RefObject<Joint>) => (
    <group ref={legRef} position={[side * 0.28, -0.05, 0]}>
      <mesh geometry={g.joint} material={m.dark} scale={0.2} castShadow={cast} />
      <mesh geometry={g.thigh} material={m.chrome} position={[0, -0.34, 0]} castShadow={cast} />
      <group ref={kneeRef} position={[0, -0.68, 0]}>
        <mesh geometry={g.joint} material={m.dark} scale={0.18} />
        <mesh geometry={g.shin} material={m.armor} position={[0, -0.3, 0]} castShadow={cast} />
        <mesh geometry={g.stripe} material={m.glow} position={[0, -0.25, 0.17]} scale={[0.25, 1, 1]} />
        <mesh geometry={g.foot} material={m.dark} position={[0, -0.6, 0.1]} castShadow={cast} />
      </group>
    </group>
  )

  const arm = (side: -1 | 1, armRef: React.RefObject<Joint>, elbowRef: React.RefObject<Joint>) => (
    <group ref={armRef} position={[side * 0.74, 0.92, 0]} rotation={[0, 0, side * 0.12]}>
      <mesh geometry={g.joint} material={m.chrome} scale={0.27} castShadow={cast} />
      <mesh geometry={g.upperArm} material={m.armor} position={[0, -0.3, 0]} castShadow={cast} />
      <group ref={elbowRef} position={[0, -0.58, 0]}>
        <mesh geometry={g.joint} material={m.dark} scale={0.15} />
        <mesh geometry={g.foreArm} material={m.chrome} position={[0, -0.25, 0]} castShadow={cast} />
        <mesh geometry={g.joint} material={m.dark} position={[0, -0.52, 0]} scale={0.17} />
      </group>
    </group>
  )

  return (
    <group ref={root}>
      <group scale={0.9}>
        <group ref={body} position={[0, 1.35, 0]}>
          <mesh geometry={g.pelvis} material={m.dark} castShadow={cast} />
          {leg(-1, legL, kneeL)}
          {leg(1, legR, kneeR)}
          <group ref={torso} position={[0, 0.6, 0]}>
            <mesh geometry={g.abdomen} material={m.dark} position={[0, -0.32, 0]} />
            <mesh geometry={g.chest} material={m.armor} position={[0, 0.3, 0]} castShadow={cast} />
            <mesh geometry={g.core} material={m.glow} position={[0, 0.38, 0.37]} rotation={[Math.PI / 2, 0, 0]} />
            <mesh geometry={g.stripe} material={m.glow} position={[0, 0.02, 0.36]} />
            <mesh geometry={g.plate} material={numberMat} position={[0, 0.35, -0.375]} rotation={[0, Math.PI, 0]} />
            {arm(-1, armL, elbowL)}
            {arm(1, armR, elbowR)}
            <mesh geometry={g.neck} material={m.dark} position={[0, 0.86, 0]} />
            <group ref={head} position={[0, 1.18, 0]}>
              <mesh geometry={g.head} material={m.chrome} castShadow={cast} />
              <mesh geometry={g.visor} material={m.glow} position={[0, 0.03, 0.34]} />
              <mesh geometry={g.ear} material={m.armor} position={[-0.42, 0, 0]} rotation={[0, 0, Math.PI / 2]} />
              <mesh geometry={g.ear} material={m.armor} position={[0.42, 0, 0]} rotation={[0, 0, Math.PI / 2]} />
              <mesh geometry={g.antenna} material={m.dark} position={[0.24, 0.45, -0.12]} />
              <mesh geometry={g.joint} material={m.glow} position={[0.24, 0.66, -0.12]} scale={0.06} />
            </group>
            <group position={[0, 0.3, -0.5]}>
              <mesh geometry={g.pack} material={m.dark} castShadow={cast} />
              <mesh geometry={g.stripe} material={m.glow} position={[0, 0.2, -0.18]} scale={[0.6, 1, 1]} />
              <mesh geometry={g.nozzle} material={m.chrome} position={[-0.2, -0.5, 0]} />
              <mesh geometry={g.nozzle} material={m.chrome} position={[0.2, -0.5, 0]} />
              <group ref={flames} position={[0, -0.62, 0]}>
                <mesh geometry={g.flame} material={m.flame} position={[-0.2, 0, 0]} />
                <mesh geometry={g.flame} material={m.flame} position={[0.2, 0, 0]} />
                <mesh geometry={g.flameCore} material={m.flameCore} position={[-0.2, 0, 0]} />
                <mesh geometry={g.flameCore} material={m.flameCore} position={[0.2, 0, 0]} />
              </group>
            </group>
          </group>
        </group>
      </group>
      <group ref={ground}>
        <mesh ref={disc} geometry={g.disc} material={m.disc} renderOrder={2} />
        <mesh ref={ring} geometry={g.ring} material={m.ring} renderOrder={3} />
      </group>
      <mesh ref={arrow} geometry={g.arrow} material={m.arrow} position={[0, 4.9, 0]} />
    </group>
  )
})

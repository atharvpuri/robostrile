'use client'

import { Pause, Repeat2 } from 'lucide-react'
import { TEAMS } from '@/lib/game/constants'
import { input } from '@/lib/game/input'
import { useGame } from '@/lib/game/store'
import { cn } from '@/lib/utils'

function formatClock(s: number) {
  const t = Math.max(0, Math.ceil(s))
  return `${Math.floor(t / 60)}:${String(t % 60).padStart(2, '0')}`
}

function Scoreboard() {
  const score = useGame((s) => s.hud.score)
  const clock = useGame((s) => s.hud.clock)
  const overtime = useGame((s) => s.hud.overtime)
  return (
    <div className="pointer-events-none absolute left-1/2 top-3 z-20 flex -translate-x-1/2 items-stretch overflow-hidden rounded-xl border border-white/10 bg-[#050916]/80 font-display shadow-2xl backdrop-blur-md">
      <div className="flex items-center gap-2 bg-gradient-to-r from-[#1d8bff] to-[#0a2c5c] px-3 py-1.5">
        <span className="text-[10px] font-bold tracking-widest text-white/80 sm:text-xs">{TEAMS[0].short}</span>
        <span className="font-sans text-2xl font-black tabular-nums text-white sm:text-3xl">{score[0]}</span>
      </div>
      <div className="flex min-w-20 flex-col items-center justify-center px-3 py-1">
        <span className={cn('font-sans text-lg font-bold tabular-nums sm:text-xl', overtime ? 'text-[#ffd23a]' : 'text-white')}>
          {overtime ? `+${formatClock(clock)}` : formatClock(clock)}
        </span>
        {overtime && <span className="text-[9px] font-bold tracking-[0.25em] text-[#ffd23a]">OVERTIME</span>}
      </div>
      <div className="flex items-center gap-2 bg-gradient-to-l from-[#ff5a1f] to-[#5c1d08] px-3 py-1.5">
        <span className="font-sans text-2xl font-black tabular-nums text-white sm:text-3xl">{score[1]}</span>
        <span className="text-[10px] font-bold tracking-widest text-white/80 sm:text-xs">{TEAMS[1].short}</span>
      </div>
    </div>
  )
}

function BoostGauge() {
  const boost = useGame((s) => s.hud.boost)
  const name = useGame((s) => s.hud.controlledName)
  const number = useGame((s) => s.hud.controlledNumber)
  const hasBall = useGame((s) => s.hud.hasBall)
  const C = 2 * Math.PI * 42
  return (
    <div className="pointer-events-none absolute left-3 top-3 z-20 flex items-center gap-3">
      <div className="relative size-16 sm:size-20">
        <svg viewBox="0 0 100 100" className="size-full -rotate-90" aria-hidden>
          <circle cx="50" cy="50" r="42" fill="rgba(5,9,22,0.75)" stroke="rgba(255,255,255,0.12)" strokeWidth="8" />
          <circle
            cx="50"
            cy="50"
            r="42"
            fill="none"
            stroke="#ffd23a"
            strokeWidth="8"
            strokeLinecap="round"
            strokeDasharray={`${(boost / 100) * C} ${C}`}
            style={{ filter: 'drop-shadow(0 0 6px rgba(255,210,58,0.8))' }}
          />
        </svg>
        <div className="absolute inset-0 flex flex-col items-center justify-center font-display">
          <span className="font-sans text-lg font-black leading-none tabular-nums text-white sm:text-xl">{Math.round(boost)}</span>
          <span className="text-[8px] tracking-[0.2em] text-[#ffd23a]">BOOST</span>
        </div>
      </div>
      <div className="hidden flex-col font-display sm:flex">
        <span className="text-[10px] tracking-[0.3em] text-[#4cc9ff]">CONTROLLING</span>
        <span className="text-base font-bold text-white">
          {name} <span className="text-white/50">#{number}</span>
        </span>
        {hasBall && <span className="text-[10px] font-bold tracking-[0.25em] text-[#ffd23a]">ON THE BALL</span>}
      </div>
    </div>
  )
}

function CenterMessage() {
  const message = useGame((s) => s.hud.message)
  const sub = useGame((s) => s.hud.sub)
  const team = useGame((s) => s.hud.messageTeam)
  if (!message) return null
  const color = team >= 0 ? TEAMS[team].glow : '#ffffff'
  const isGoal = message === 'GOAL!'
  return (
    <div className="pointer-events-none absolute inset-0 z-20 flex flex-col items-center justify-center" role="status" aria-live="polite">
      <span
        key={message}
        className={cn(
          'animate-in zoom-in-50 fade-in font-display font-black italic tracking-tight duration-300',
          isGoal ? 'text-7xl sm:text-9xl' : 'text-6xl sm:text-8xl',
        )}
        style={{ color, textShadow: `0 0 30px ${color}, 0 0 60px ${color}, 0 4px 0 rgba(0,0,0,0.5)` }}
      >
        {message}
      </span>
      {sub && (
        <span className="mt-2 rounded-full bg-black/50 px-4 py-1 font-display text-xs font-bold tracking-[0.35em] text-white backdrop-blur sm:text-sm">
          {sub}
        </span>
      )}
    </div>
  )
}

function ChargeBar() {
  const charge = useGame((s) => s.hud.charge)
  if (charge <= 0.02) return null
  return (
    <div className="pointer-events-none absolute bottom-28 left-1/2 z-20 w-48 -translate-x-1/2 sm:bottom-16">
      <div className="mb-1 text-center font-display text-[10px] font-bold tracking-[0.3em] text-white/80">SHOT POWER</div>
      <div className="h-2.5 overflow-hidden rounded-full border border-white/20 bg-black/60">
        <div
          className="h-full rounded-full bg-gradient-to-r from-[#ffd23a] via-[#ffa23a] to-[#ff3d1f]"
          style={{ width: `${charge * 100}%` }}
        />
      </div>
    </div>
  )
}

export function Hud({ touch }: { touch: boolean }) {
  const setScreen = useGame((s) => s.setScreen)
  return (
    <>
      <Scoreboard />
      <BoostGauge />
      <CenterMessage />
      <ChargeBar />
      <div className="absolute right-3 top-3 z-30 flex gap-2">
        <button
          type="button"
          aria-label="Switch player"
          className="flex h-11 items-center gap-1.5 rounded-xl border border-white/15 bg-[#050916]/80 px-3 font-display text-[10px] font-bold tracking-widest text-white backdrop-blur-md active:scale-95"
          onPointerDown={(e) => {
            e.stopPropagation()
            input.switch = true
          }}
          onPointerUp={() => (input.switch = false)}
          onPointerLeave={() => (input.switch = false)}
        >
          <Repeat2 className="size-4 text-[#4cc9ff]" aria-hidden />
          SWITCH
        </button>
        <button
          type="button"
          aria-label="Pause game"
          className="flex size-11 items-center justify-center rounded-xl border border-white/15 bg-[#050916]/80 text-white backdrop-blur-md active:scale-95"
          onClick={() => setScreen('paused')}
        >
          <Pause className="size-5" aria-hidden />
        </button>
      </div>
      {!touch && (
        <div className="pointer-events-none absolute bottom-3 left-1/2 z-20 -translate-x-1/2 rounded-full border border-white/10 bg-[#050916]/70 px-4 py-1.5 text-center text-[11px] text-white/70 backdrop-blur">
          <kbd className="font-bold text-white">WASD</kbd> move · <kbd className="font-bold text-white">J</kbd> shoot (hold) ·{' '}
          <kbd className="font-bold text-white">K</kbd> pass · <kbd className="font-bold text-white">L</kbd> lob ·{' '}
          <kbd className="font-bold text-white">I</kbd> tackle/skill · <kbd className="font-bold text-white">Space</kbd> jump ·{' '}
          <kbd className="font-bold text-white">Shift</kbd> boost · <kbd className="font-bold text-white">Q</kbd> switch
        </div>
      )}
    </>
  )
}

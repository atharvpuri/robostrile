'use client'

import { useFrame } from '@react-three/fiber'
import { useEffect, useLayoutEffect, useMemo, useRef } from 'react'
import * as THREE from 'three'
import { GOAL_DEPTH, GOAL_H, GOAL_HALF_W, HALF_L, HALF_W, POST_R, TEAMS, WALL_H } from '@/lib/game/constants'
import { useGame } from '@/lib/game/store'
import { world } from '@/lib/game/world'

function pitchTexture() {
  const W = 1024
  const H = Math.round((W * HALF_L) / HALF_W)
  const k = W / (HALF_W * 2)
  const c = document.createElement('canvas')
  c.width = W
  c.height = H
  const ctx = c.getContext('2d')!
  const stripes = 16
  for (let i = 0; i < stripes; i++) {
    ctx.fillStyle = i % 2 ? '#1a6331' : '#15552a'
    ctx.fillRect(0, (i * H) / stripes, W, H / stripes + 1)
  }
  for (let i = 0; i < 26000; i++) {
    ctx.fillStyle = Math.random() < 0.5 ? 'rgba(255,255,255,0.035)' : 'rgba(0,0,0,0.06)'
    ctx.fillRect(Math.random() * W, Math.random() * H, 2, 3)
  }
  const top = ctx.createLinearGradient(0, 0, 0, H / 2)
  top.addColorStop(0, 'rgba(29,139,255,0.22)')
  top.addColorStop(1, 'rgba(29,139,255,0)')
  ctx.fillStyle = top
  ctx.fillRect(0, 0, W, H / 2)
  const bot = ctx.createLinearGradient(0, H, 0, H / 2)
  bot.addColorStop(0, 'rgba(255,90,31,0.22)')
  bot.addColorStop(1, 'rgba(255,90,31,0)')
  ctx.fillStyle = bot
  ctx.fillRect(0, H / 2, W, H / 2)

  ctx.strokeStyle = 'rgba(255,255,255,0.9)'
  ctx.lineWidth = 0.24 * k
  const inset = 0.8 * k
  ctx.strokeRect(inset, inset, W - inset * 2, H - inset * 2)
  ctx.beginPath()
  ctx.moveTo(inset, H / 2)
  ctx.lineTo(W - inset, H / 2)
  ctx.stroke()
  ctx.beginPath()
  ctx.arc(W / 2, H / 2, 9.15 * k, 0, Math.PI * 2)
  ctx.stroke()
  ctx.fillStyle = 'rgba(255,255,255,0.9)'
  ctx.beginPath()
  ctx.arc(W / 2, H / 2, 0.45 * k, 0, Math.PI * 2)
  ctx.fill()
  for (const end of [0, 1]) {
    const y0 = end === 0 ? inset : H - inset
    const dir = end === 0 ? 1 : -1
    const boxW = 44 * k
    const boxD = 17 * k
    ctx.strokeRect(W / 2 - boxW / 2, end === 0 ? y0 : y0 - boxD, boxW, boxD)
    const gW = (GOAL_HALF_W * 2 + 6) * k
    const gD = 6 * k
    ctx.strokeRect(W / 2 - gW / 2, end === 0 ? y0 : y0 - gD, gW, gD)
    const spotY = y0 + dir * 12 * k
    ctx.beginPath()
    ctx.arc(W / 2, spotY, 0.4 * k, 0, Math.PI * 2)
    ctx.fill()
    ctx.save()
    ctx.beginPath()
    ctx.rect(0, end === 0 ? y0 + boxD : 0, W, end === 0 ? H : y0 - boxD)
    ctx.clip()
    ctx.beginPath()
    ctx.arc(W / 2, spotY, 9.15 * k, 0, Math.PI * 2)
    ctx.stroke()
    ctx.restore()
  }
  for (const [cx, cy, a0] of [
    [inset, inset, 0],
    [W - inset, inset, Math.PI / 2],
    [W - inset, H - inset, Math.PI],
    [inset, H - inset, Math.PI * 1.5],
  ]) {
    ctx.beginPath()
    ctx.arc(cx, cy, 1.5 * k, a0, a0 + Math.PI / 2)
    ctx.stroke()
  }
  const tex = new THREE.CanvasTexture(c)
  tex.colorSpace = THREE.SRGBColorSpace
  tex.anisotropy = 8
  return tex
}

function netTexture() {
  const c = document.createElement('canvas')
  c.width = c.height = 64
  const ctx = c.getContext('2d')!
  ctx.strokeStyle = 'rgba(255,255,255,1)'
  ctx.lineWidth = 3
  ctx.beginPath()
  ctx.moveTo(32, 0)
  ctx.lineTo(32, 64)
  ctx.moveTo(0, 32)
  ctx.lineTo(64, 32)
  ctx.stroke()
  const t = new THREE.CanvasTexture(c)
  t.wrapS = t.wrapT = THREE.RepeatWrapping
  return t
}

function boardTexture() {
  const c = document.createElement('canvas')
  c.width = 1024
  c.height = 64
  const ctx = c.getContext('2d')!
  const g = ctx.createLinearGradient(0, 0, 1024, 0)
  g.addColorStop(0, '#0a2c5c')
  g.addColorStop(0.5, '#141a33')
  g.addColorStop(1, '#5c1d08')
  ctx.fillStyle = g
  ctx.fillRect(0, 0, 1024, 64)
  ctx.font = 'bold 40px system-ui, sans-serif'
  ctx.textBaseline = 'middle'
  ctx.fillStyle = '#e6f3ff'
  for (let i = 0; i < 4; i++) ctx.fillText('ROBOSTRIKE ARENA', 20 + i * 256 * 1, 34)
  const t = new THREE.CanvasTexture(c)
  t.colorSpace = THREE.SRGBColorSpace
  t.wrapS = THREE.RepeatWrapping
  return t
}

function Pitch() {
  const tex = useMemo(pitchTexture, [])
  return (
    <>
      <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
        <planeGeometry args={[HALF_W * 2, HALF_L * 2]} />
        <meshStandardMaterial map={tex} roughness={0.9} metalness={0} />
      </mesh>
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, -0.05, 0]} receiveShadow>
        <planeGeometry args={[420, 420]} />
        <meshStandardMaterial color="#070b16" roughness={0.95} />
      </mesh>
    </>
  )
}

const glass = new THREE.MeshStandardMaterial({
  color: '#8fd3ff',
  transparent: true,
  opacity: 0.06,
  depthWrite: false,
  side: THREE.DoubleSide,
  metalness: 0.2,
  roughness: 0.05,
})

function Strip({
  position,
  size,
  color,
  intensity = 2.5,
}: {
  position: [number, number, number]
  size: [number, number, number]
  color: string
  intensity?: number
}) {
  return (
    <mesh position={position}>
      <boxGeometry args={size} />
      <meshStandardMaterial color={color} emissive={color} emissiveIntensity={intensity} toneMapped={false} />
    </mesh>
  )
}

function Walls() {
  const board = useMemo(boardTexture, [])
  const sideW = HALF_W - GOAL_HALF_W
  const blue = TEAMS[0].glow
  const orange = TEAMS[1].glow
  return (
    <group>
      {[-1, 1].map((sx) => (
        <group key={`side${sx}`}>
          <mesh position={[sx * HALF_W, WALL_H / 2, 0]} rotation={[0, Math.PI / 2, 0]} material={glass}>
            <planeGeometry args={[HALF_L * 2, WALL_H]} />
          </mesh>
          <mesh position={[sx * (HALF_W + 0.05), 0.75, 0]} rotation={[0, (-sx * Math.PI) / 2, 0]}>
            <planeGeometry args={[HALF_L * 2, 1.5]} />
            <meshStandardMaterial
              map={board}
              emissiveMap={board}
              emissive="#ffffff"
              emissiveIntensity={0.9}
              toneMapped={false}
              map-repeat={[3, 1]}
            />
          </mesh>
          <Strip position={[sx * HALF_W, 1.55, -HALF_L / 2]} size={[0.2, 0.12, HALF_L]} color={blue} />
          <Strip position={[sx * HALF_W, 1.55, HALF_L / 2]} size={[0.2, 0.12, HALF_L]} color={orange} />
          <Strip position={[sx * HALF_W, WALL_H, 0]} size={[0.25, 0.25, HALF_L * 2]} color="#cfe6ff" intensity={1.4} />
          {[-1, 1].map((sz) => (
            <Strip
              key={sz}
              position={[sx * HALF_W, WALL_H / 2, sz * HALF_L]}
              size={[0.3, WALL_H, 0.3]}
              color={sz < 0 ? blue : orange}
              intensity={1.8}
            />
          ))}
        </group>
      ))}
      {[-1, 1].map((sz) => {
        const col = sz < 0 ? blue : orange
        return (
          <group key={`end${sz}`}>
            {[-1, 1].map((sx) => (
              <group key={sx}>
                <mesh position={[sx * (GOAL_HALF_W + sideW / 2), WALL_H / 2, sz * HALF_L]} material={glass}>
                  <planeGeometry args={[sideW, WALL_H]} />
                </mesh>
                <Strip position={[sx * (GOAL_HALF_W + sideW / 2), 0.08, sz * HALF_L]} size={[sideW, 0.12, 0.2]} color={col} />
              </group>
            ))}
            <mesh position={[0, GOAL_H + (WALL_H - GOAL_H) / 2, sz * HALF_L]} material={glass}>
              <planeGeometry args={[GOAL_HALF_W * 2, WALL_H - GOAL_H]} />
            </mesh>
            <Strip position={[0, WALL_H, sz * HALF_L]} size={[HALF_W * 2, 0.25, 0.25]} color="#cfe6ff" intensity={1.4} />
          </group>
        )
      })}
    </group>
  )
}

function Goal({ side }: { side: -1 | 1 }) {
  const team = side < 0 ? TEAMS[0] : TEAMS[1]
  const net = useMemo(() => netTexture(), [])
  const z0 = side * HALF_L
  const zb = side * (HALF_L + GOAL_DEPTH)
  const zm = side * (HALF_L + GOAL_DEPTH / 2)
  const backMap = useMemo(() => {
    const t = net.clone()
    t.repeat.set(GOAL_HALF_W * 2, GOAL_H)
    t.needsUpdate = true
    return t
  }, [net])
  const sideMap = useMemo(() => {
    const t = net.clone()
    t.repeat.set(GOAL_DEPTH, GOAL_H)
    t.needsUpdate = true
    return t
  }, [net])
  const roofMap = useMemo(() => {
    const t = net.clone()
    t.repeat.set(GOAL_HALF_W * 2, GOAL_DEPTH)
    t.needsUpdate = true
    return t
  }, [net])

  const netProps = {
    transparent: true,
    opacity: 0.55,
    depthWrite: false,
    side: THREE.DoubleSide,
    toneMapped: false,
    color: team.glow,
  } as const

  return (
    <group>
      {[-1, 1].map((sx) => (
        <mesh key={sx} position={[sx * GOAL_HALF_W, GOAL_H / 2, z0]} castShadow>
          <cylinderGeometry args={[POST_R, POST_R, GOAL_H, 16]} />
          <meshStandardMaterial color="#ffffff" emissive="#ffffff" emissiveIntensity={0.6} metalness={0.4} roughness={0.2} />
        </mesh>
      ))}
      <mesh position={[0, GOAL_H, z0]} rotation={[0, 0, Math.PI / 2]} castShadow>
        <cylinderGeometry args={[POST_R, POST_R, GOAL_HALF_W * 2 + POST_R * 2, 16]} />
        <meshStandardMaterial color="#ffffff" emissive="#ffffff" emissiveIntensity={0.6} metalness={0.4} roughness={0.2} />
      </mesh>
      <Strip position={[0, GOAL_H + 0.45, z0]} size={[GOAL_HALF_W * 2, 0.12, 0.12]} color={team.glow} intensity={4} />
      {[-1, 1].map((sx) => (
        <mesh key={`b${sx}`} position={[sx * GOAL_HALF_W, GOAL_H / 2, zb]}>
          <cylinderGeometry args={[0.12, 0.12, GOAL_H, 8]} />
          <meshStandardMaterial color="#2a3245" metalness={0.8} roughness={0.3} />
        </mesh>
      ))}
      <mesh position={[0, GOAL_H / 2, zb]}>
        <planeGeometry args={[GOAL_HALF_W * 2, GOAL_H]} />
        <meshBasicMaterial map={backMap} {...netProps} />
      </mesh>
      {[-1, 1].map((sx) => (
        <mesh key={`s${sx}`} position={[sx * GOAL_HALF_W, GOAL_H / 2, zm]} rotation={[0, Math.PI / 2, 0]}>
          <planeGeometry args={[GOAL_DEPTH, GOAL_H]} />
          <meshBasicMaterial map={sideMap} {...netProps} />
        </mesh>
      ))}
      <mesh position={[0, GOAL_H, zm]} rotation={[Math.PI / 2, 0, 0]}>
        <planeGeometry args={[GOAL_HALF_W * 2, GOAL_DEPTH]} />
        <meshBasicMaterial map={roofMap} {...netProps} />
      </mesh>
      <mesh position={[0, 0.02, zm]} rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
        <planeGeometry args={[GOAL_HALF_W * 2, GOAL_DEPTH]} />
        <meshStandardMaterial color={team.dark} emissive={team.main} emissiveIntensity={0.25} roughness={0.6} />
      </mesh>
      <Strip position={[0, 0.06, z0]} size={[GOAL_HALF_W * 2, 0.06, 0.3]} color={team.glow} intensity={3} />
      <pointLight position={[0, 4, zm]} color={team.glow} intensity={40} distance={22} decay={2} />
    </group>
  )
}

function Stands({ quality }: { quality: 'high' | 'performance' }) {
  const rows = quality === 'high' ? 9 : 6
  const crowdRef = useRef<THREE.InstancedMesh>(null)
  const layout = useMemo(() => {
    const tiers: { pos: [number, number, number]; size: [number, number, number]; rotY: number }[] = []
    const fans: { x: number; y: number; z: number; rotY: number; phase: number; color: THREE.Color }[] = []
    const palette = [TEAMS[0].main, TEAMS[0].glow, TEAMS[1].main, TEAMS[1].glow, '#e5e7eb', '#1f2937', '#facc15']
    const sides = [
      { axis: 'x' as const, sign: -1, len: HALF_L * 2 + 12, base: HALF_W + 4 },
      { axis: 'x' as const, sign: 1, len: HALF_L * 2 + 12, base: HALF_W + 4 },
      { axis: 'z' as const, sign: -1, len: HALF_W * 2 + 12, base: HALF_L + GOAL_DEPTH + 3 },
      { axis: 'z' as const, sign: 1, len: HALF_W * 2 + 12, base: HALF_L + GOAL_DEPTH + 3 },
    ]
    for (const s of sides) {
      const rotY = s.axis === 'x' ? (s.sign > 0 ? -Math.PI / 2 : Math.PI / 2) : s.sign > 0 ? Math.PI : 0
      for (let r = 0; r < rows; r++) {
        const dist = s.base + r * 2.4
        const h = 1.2 + r * 1.5
        const pos: [number, number, number] =
          s.axis === 'x' ? [s.sign * dist, h / 2, 0] : [0, h / 2, s.sign * dist]
        const size: [number, number, number] = s.axis === 'x' ? [2.4, h, s.len] : [s.len, h, 2.4]
        tiers.push({ pos, size, rotY })
        const count = Math.floor(s.len / 1.45)
        for (let i = 0; i < count; i++) {
          if (Math.random() < 0.08) continue
          const along = -s.len / 2 + (i + 0.5) * (s.len / count) + (Math.random() - 0.5) * 0.4
          const side = s.axis === 'z' ? s.sign : 0
          const teamBias = side < 0 ? 0.65 : side > 0 ? 0.35 : 0.5
          const roll = Math.random()
          let color: string
          if (roll < 0.82) color = Math.random() < teamBias ? palette[Math.random() < 0.6 ? 0 : 1] : palette[Math.random() < 0.6 ? 2 : 3]
          else color = palette[4 + Math.floor(Math.random() * 3)]
          fans.push({
            x: s.axis === 'x' ? s.sign * dist : along,
            y: h + 0.55,
            z: s.axis === 'x' ? along : s.sign * dist,
            rotY,
            phase: Math.random() * Math.PI * 2,
            color: new THREE.Color(color),
          })
        }
      }
    }
    return { tiers, fans }
  }, [rows])

  const dummy = useMemo(() => new THREE.Object3D(), [])
  useLayoutEffect(() => {
    const m = crowdRef.current
    if (!m) return
    layout.fans.forEach((f, i) => {
      dummy.position.set(f.x, f.y, f.z)
      dummy.rotation.set(0, f.rotY, 0)
      dummy.updateMatrix()
      m.setMatrixAt(i, dummy.matrix)
      m.setColorAt(i, f.color)
    })
    m.instanceMatrix.needsUpdate = true
    if (m.instanceColor) m.instanceColor.needsUpdate = true
  }, [layout, dummy])

  const frame = useRef(0)
  useFrame((state) => {
    const m = crowdRef.current
    if (!m) return
    frame.current++
    const excited = world.phase === 'goal'
    if (!excited && quality === 'performance') return
    if (!excited && frame.current % 2 !== 0) return
    const t = state.clock.elapsedTime
    const amp = excited ? 0.7 : 0.08
    const speed = excited ? 12 : 3
    layout.fans.forEach((f, i) => {
      dummy.position.set(f.x, f.y + Math.abs(Math.sin(t * speed + f.phase)) * amp, f.z)
      dummy.rotation.set(0, f.rotY, 0)
      dummy.updateMatrix()
      m.setMatrixAt(i, dummy.matrix)
    })
    m.instanceMatrix.needsUpdate = true
  })

  return (
    <group>
      {layout.tiers.map((t, i) => (
        <mesh key={i} position={t.pos} receiveShadow={quality === 'high'}>
          <boxGeometry args={t.size} />
          <meshStandardMaterial color={i % 2 ? '#141b2d' : '#18213a'} roughness={0.8} metalness={0.2} />
        </mesh>
      ))}
      <instancedMesh ref={crowdRef} args={[undefined, undefined, layout.fans.length]} frustumCulled={false}>
        <boxGeometry args={[0.75, 1.1, 0.5]} />
        <meshStandardMaterial roughness={0.7} />
      </instancedMesh>
    </group>
  )
}

function Floodlights() {
  const spots = [
    [-1, -1],
    [1, -1],
    [-1, 1],
    [1, 1],
  ] as const
  return (
    <group>
      {spots.map(([sx, sz], i) => {
        const x = sx * (HALF_W + 26)
        const z = sz * (HALF_L + 22)
        const yaw = Math.atan2(-x, -z)
        return (
          <group key={i} position={[x, 0, z]}>
            <mesh position={[0, 24, 0]}>
              <cylinderGeometry args={[0.5, 0.9, 48, 10]} />
              <meshStandardMaterial color="#1f2937" metalness={0.8} roughness={0.4} />
            </mesh>
            <group position={[0, 48, 0]} rotation={[0, yaw, 0]}>
              <group rotation={[0.45, 0, 0]}>
                <mesh>
                  <boxGeometry args={[10, 5, 0.8]} />
                  <meshStandardMaterial color="#111827" metalness={0.7} roughness={0.4} />
                </mesh>
                {Array.from({ length: 8 }).map((_, j) => (
                  <mesh key={j} position={[-3.75 + (j % 4) * 2.5, j < 4 ? 1.1 : -1.1, 0.45]}>
                    <circleGeometry args={[0.85, 20]} />
                    <meshBasicMaterial color="#fffbea" toneMapped={false} />
                  </mesh>
                ))}
              </group>
            </group>
          </group>
        )
      })}
    </group>
  )
}

function useScoreTexture() {
  const canvas = useMemo(() => {
    const c = document.createElement('canvas')
    c.width = 1024
    c.height = 384
    return c
  }, [])
  const texture = useMemo(() => {
    const t = new THREE.CanvasTexture(canvas)
    t.colorSpace = THREE.SRGBColorSpace
    return t
  }, [canvas])
  const score = useGame((s) => s.hud.score)
  const clock = useGame((s) => Math.ceil(s.hud.clock))
  const screen = useGame((s) => s.screen)

  useEffect(() => {
    const ctx = canvas.getContext('2d')!
    const W = canvas.width
    const H = canvas.height
    ctx.fillStyle = '#050916'
    ctx.fillRect(0, 0, W, H)
    const g = ctx.createLinearGradient(0, 0, W, 0)
    g.addColorStop(0, 'rgba(29,139,255,0.35)')
    g.addColorStop(0.5, 'rgba(5,9,22,0)')
    g.addColorStop(1, 'rgba(255,90,31,0.35)')
    ctx.fillStyle = g
    ctx.fillRect(0, 0, W, H)
    ctx.textAlign = 'center'
    ctx.textBaseline = 'middle'
    ctx.font = 'bold 64px system-ui, sans-serif'
    ctx.fillStyle = TEAMS[0].glow
    ctx.fillText(TEAMS[0].name, W * 0.2, 90)
    ctx.fillStyle = TEAMS[1].glow
    ctx.fillText(TEAMS[1].name, W * 0.8, 90)
    ctx.fillStyle = '#ffffff'
    ctx.font = 'bold 190px system-ui, sans-serif'
    const live = screen !== 'menu'
    ctx.fillText(live ? String(score[0]) : '0', W * 0.2, 250)
    ctx.fillText(live ? String(score[1]) : '0', W * 0.8, 250)
    ctx.font = 'bold 110px system-ui, sans-serif'
    const m = Math.floor(Math.max(0, clock) / 60)
    const s = Math.max(0, clock) % 60
    ctx.fillStyle = '#ffd23a'
    ctx.fillText(live ? `${m}:${String(s).padStart(2, '0')}` : 'LIVE', W / 2, 200)
    texture.needsUpdate = true
  }, [canvas, texture, score, clock, screen])

  return texture
}

function Jumbotrons() {
  const tex = useScoreTexture()
  return (
    <group>
      {[-1, 1].map((sz) => (
        <group key={sz} position={[0, 34, sz * (HALF_L + 34)]} rotation={[0, sz > 0 ? Math.PI : 0, 0]}>
          <mesh>
            <boxGeometry args={[34, 14, 1.2]} />
            <meshStandardMaterial color="#0b1020" metalness={0.8} roughness={0.35} />
          </mesh>
          <mesh position={[0, 0, 0.62]}>
            <planeGeometry args={[32, 12]} />
            <meshBasicMaterial map={tex} toneMapped={false} />
          </mesh>
          <mesh position={[0, -14, 0]}>
            <boxGeometry args={[1.2, 14, 1.2]} />
            <meshStandardMaterial color="#1f2937" metalness={0.8} roughness={0.4} />
          </mesh>
        </group>
      ))}
    </group>
  )
}

export function Stadium({ quality }: { quality: 'high' | 'performance' }) {
  return (
    <group>
      <Pitch />
      <Walls />
      <Goal side={-1} />
      <Goal side={1} />
      <Stands quality={quality} />
      <Floodlights />
      <Jumbotrons />
    </group>
  )
}

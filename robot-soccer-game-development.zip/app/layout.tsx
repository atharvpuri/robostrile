import { Analytics } from '@vercel/analytics/next'
import type { Metadata, Viewport } from 'next'
import { Geist, Orbitron } from 'next/font/google'
import './globals.css'

const geist = Geist({ subsets: ['latin'], variable: '--font-geist' })
const orbitron = Orbitron({ subsets: ['latin'], variable: '--font-orbitron', weight: ['500', '700', '900'] })

export const metadata: Metadata = {
  title: 'RoboStrike Arena — 3v3 Rocket Robot Football',
  description:
    'A high-octane 3D football game where jet-powered robots dribble, pass, volley and slide-tackle in a neon stadium. Built for Android and desktop browsers.',
  generator: 'v0.app',
  applicationName: 'RoboStrike Arena',
  appleWebApp: { capable: true, title: 'RoboStrike', statusBarStyle: 'black-translucent' },
  icons: {
    icon: [
      { url: '/icon-light-32x32.png', media: '(prefers-color-scheme: light)' },
      { url: '/icon-dark-32x32.png', media: '(prefers-color-scheme: dark)' },
      { url: '/icon.svg', type: 'image/svg+xml' },
    ],
    apple: '/apple-icon.png',
  },
}

export const viewport: Viewport = {
  colorScheme: 'dark',
  themeColor: '#040814',
  width: 'device-width',
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  viewportFit: 'cover',
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className={`${geist.variable} ${orbitron.variable} dark bg-[#040814]`}>
      <body className="font-sans antialiased overscroll-none">
        {children}
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
